import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import crypto from "crypto";
import multer from "multer";
import Papa from "papaparse";
import bcrypt from "bcryptjs";
import * as ninjaone from "./services/ninjaone";
import * as huntress from "./services/huntress";
import * as dropsuite from "./services/dropsuite";
import * as connectwise from "./services/connectwise";
import * as roadmap from "./services/roadmap";
import { generateSummaryHtml } from "./services/export";
import { isEmailConfigured, sendReminderEmail } from "./services/email";
import { log } from "./index";
import { insertTbrSnapshotSchema, insertTbrScheduleSchema, insertTbrStagingSchema, loginUserSchema, createUserSchema } from "@shared/schema";
import type { MfaReport, LicenseReport, SecuritySummary, TicketSummary, DeviceHealthSummary, InsertTbrSnapshot, MarginInsight, AgreementAdditionInfo } from "@shared/schema";
import { storage } from "./storage";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

interface TokenSession {
  userId: number;
  email: string;
  displayName: string;
  role: string;
  pageAccess: Record<string, boolean> | null;
}

const tokenSessions = new Map<string, TokenSession>();

function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    const session = tokenSessions.get(token);
    if (session) {
      (req as any).user = session;
      return next();
    }
  }
  res.status(401).json({ message: "Unauthorized" });
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user as TokenSession | undefined;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
}

function requireEditor(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user as TokenSession | undefined;
  if (!user || (user.role !== "admin" && user.role !== "editor")) {
    return res.status(403).json({ message: "Editor access required" });
  }
  next();
}

function fuzzyNameMatch(cwName: string, platformName: string): boolean {
  const SUFFIXES = /\b(inc|llc|pllc|corp|ltd|co|group|services|solutions|tech|technologies|consulting|associates|management|systems|partners|company|international|properties|enterprises|law|legal|psc|pc|dds|cpa|md|dvm)\b/g;
  function norm(s: string): string {
    return s.toLowerCase()
      .replace(/&/g, " and ")
      .replace(SUFFIXES, " ")
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ").trim();
  }
  const a = norm(cwName);
  const b = norm(platformName);
  if (!a || !b) return false;
  if (a === b) return true;
  if (a.includes(b) || b.includes(a)) return true;
  const tokA = a.split(" ").filter(t => t.length > 2);
  const tokB = b.split(" ").filter(t => t.length > 2);
  if (tokA.length === 0 || tokB.length === 0) return false;
  const shorter = tokA.length <= tokB.length ? tokA : tokB;
  const longer  = tokA.length <= tokB.length ? tokB : tokA;
  const hits = shorter.filter(t => longer.some(lt => lt === t || lt.includes(t) || t.includes(lt))).length;
  return hits >= Math.ceil(shorter.length * 0.8);
}

async function refreshStackForAccount(
  account: any,
  mapping: any,
  prefetched: { ninjaOrgs?: any[], huntressOrgs?: any[], cippTenants?: any[] } = {}
): Promise<any> {
  const current: any = account.stackCompliance || {
    ninjaRmm: null, huntressEdr: null, huntressItdr: null, huntressSat: null,
    dropSuite: null, dropsuiteNeedsMapping: null, zorusDns: null, connectSecure: null, huntressSiem: null,
    msBizPremium: null, secureScore: null, lastRefreshed: null, manualOverrides: {},
  };
  const updated = { ...current };

  try {
    const ninjaOrgs = prefetched.ninjaOrgs ?? await ninjaone.getOrganizations();
    const ninjaOrgId = mapping?.ninjaOrgId ?? null;
    const ninjaOrg = ninjaOrgId
      ? ninjaOrgs.find((o: any) => o.id === ninjaOrgId)
      : ninjaOrgs.find((o: any) => fuzzyNameMatch(account.companyName, o.name || ""));
    updated.ninjaRmm = ninjaOrg ? true : false;
    if (ninjaOrg) {
      log(`Stack [${account.companyName}] → Ninja matched: ${ninjaOrg.name}`);
      try {
        const swFlags = await ninjaone.getInstalledSoftwareFlags(ninjaOrg.id);
        updated.zorusDns = swFlags.hasZorus ? true : false;
        updated.dropSuite = swFlags.hasDropSuite ? true : false;
        updated.connectSecure = swFlags.hasConnectSecure ? true : false;
        log(`Stack [${account.companyName}] → Software: Zorus=${swFlags.hasZorus}, DropSuite=${swFlags.hasDropSuite}, ConnectSecure=${swFlags.hasConnectSecure}`);
      } catch (se: any) {
        log(`Stack [${account.companyName}] → Software scan error: ${se.message}`);
      }
    } else {
      log(`Stack [${account.companyName}] → Ninja: no match`);
    }
  } catch (e: any) {
    log(`Stack refresh Ninja error for ${account.companyName}: ${e.message}`);
  }

  try {
    const huntressOrgs = prefetched.huntressOrgs ?? await huntress.getOrganizations();
    const huntressOrgId = mapping?.huntressOrgId ?? null;
    const huntressOrg = huntressOrgId
      ? huntressOrgs.find((o: any) => o.id === huntressOrgId)
      : huntressOrgs.find((o: any) => fuzzyNameMatch(account.companyName, o.name || ""));
    if (huntressOrg) {
      log(`Stack [${account.companyName}] → Huntress matched: ${huntressOrg.name}`);
      try {
        const orgFlags = await huntress.getOrgStackFlags(huntressOrg.id);
        // EDR: org must have active agents — existence alone is not sufficient
        updated.huntressEdr = orgFlags.hasEdr ? true : false;
        updated.huntressItdr = orgFlags.hasItdr ? true : false;
        updated.huntressSat = orgFlags.hasSat ? true : false;
        updated.huntressSiem = orgFlags.hasSiem ? true : false;
        log(`Stack [${account.companyName}] → Huntress flags: EDR=${orgFlags.hasEdr}(${orgFlags.agentCount} agents), ITDR=${orgFlags.hasItdr}(${orgFlags.identityCount} identities), SAT=${orgFlags.hasSat}(${orgFlags.satLearnerCount} learners), SIEM=${orgFlags.hasSiem}`);
      } catch (he: any) {
        log(`Stack [${account.companyName}] → Huntress org detail error: ${he.message}`);
        // If we can't get flags, only mark EDR true if org exists (conservative fallback)
        updated.huntressEdr = true;
      }
    } else {
      log(`Stack [${account.companyName}] → Huntress: no match`);
      updated.huntressEdr = false;
    }
  } catch (e: any) {
    log(`Stack refresh Huntress error for ${account.companyName}: ${e.message}`);
  }

  const { isConfigured: cippConfigured, getClientData: cippGetClientData, getTenants: cippGetTenants } = await import("./services/cipp.js");
  let cippTenantFilter: string | null = null;
  if (cippConfigured()) {
    try {
      cippTenantFilter = mapping?.cippTenantId ?? null;
      if (!cippTenantFilter) {
        const cippTenants = prefetched.cippTenants ?? await cippGetTenants();
        const matched = cippTenants.find((t: any) => fuzzyNameMatch(account.companyName, t.displayName || ""));
        if (matched) cippTenantFilter = matched.defaultDomainName || matched.id;
      }
      if (cippTenantFilter) {
        const cippData = await cippGetClientData(cippTenantFilter);
        updated.msBizPremium = cippData.msBizPremium;
        updated.secureScore = cippData.secureScore;
        log(`Stack [${account.companyName}] → CIPP tenant: ${cippTenantFilter}`);
      }
    } catch (e: any) {
      log(`Stack refresh CIPP error for ${account.companyName}: ${e.message}`);
    }
  }

  if (dropsuite.isConfigured()) {
    if (updated.dropSuite === true) {
      updated.dropsuiteNeedsMapping = false;
      log(`Stack [${account.companyName}] → DropSuite: already detected via NinjaOne software scan`);
    } else {
      const dropsuiteUserId: string | null = mapping?.dropsuiteUserId ?? null;
      if (dropsuiteUserId) {
        updated.dropSuite = true;
        updated.dropsuiteNeedsMapping = false;
        log(`Stack [${account.companyName}] → DropSuite: matched via manual mapping (id=${dropsuiteUserId})`);
      } else if (cippTenantFilter) {
        const hasDomain = await dropsuite.checkDomainHasBackup(cippTenantFilter);
        updated.dropSuite = hasDomain;
        updated.dropsuiteNeedsMapping = false;
        log(`Stack [${account.companyName}] → DropSuite: domain check "${cippTenantFilter}" = ${hasDomain}`);
      } else {
        const dsInfo = await dropsuite.getAccountBackupStatus(account.companyName);
        updated.dropSuite = dsInfo.hasBackup;
        updated.dropsuiteNeedsMapping = false;
        log(`Stack [${account.companyName}] → DropSuite: name match = ${dsInfo.hasBackup}`);
      }
    }
  }

  const manualOverrides = current.manualOverrides || {};
  Object.keys(manualOverrides).forEach(key => {
    if (manualOverrides[key] !== undefined) (updated as any)[key] = manualOverrides[key];
  });
  updated.lastRefreshed = new Date().toISOString();
  return updated;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/cw-debug/financial-breakdown/:companyId", async (req: Request, res: Response) => {
    try {
      const cwCompanyId = parseInt(req.params.companyId);
      const dateFrom = (req.query.from as string) || "2025-01-01";
      const dateTo = (req.query.to as string) || "2025-12-31";

      const apiGet = connectwise.apiGet;

      const invoices = await apiGet("/finance/invoices", {
        conditions: `company/id = ${cwCompanyId} AND date >= [${dateFrom}] AND date <= [${dateTo}]`,
        pageSize: "1000",
        orderBy: "date asc",
      });

      let agrInvoiceRevenue = 0;
      let stdInvoiceRevenue = 0;
      let miscInvoiceRevenue = 0;
      let progressInvoiceRevenue = 0;
      const invoiceBreakdown: any[] = [];
      for (const inv of invoices) {
        const amount = inv.total || 0;
        const type = inv.type || "Unknown";
        invoiceBreakdown.push({ id: inv.id, number: inv.invoiceNumber, type, total: amount, date: inv.date });
        if (type === "Agreement") agrInvoiceRevenue += amount;
        else if (type === "Standard") stdInvoiceRevenue += amount;
        else if (type === "Miscellaneous") miscInvoiceRevenue += amount;
        else if (type === "Progress") progressInvoiceRevenue += amount;
      }

      let allTimeRows: any[][] = [];
      let timeCols: string[] = [];
      let tPage = 1;
      while (true) {
        const timeReport = await apiGet("/system/reports/Time", {
          conditions: `company_recid = ${cwCompanyId} AND date_invoice >= [${dateFrom}] AND date_invoice <= [${dateTo}]`,
          pageSize: "250",
          page: String(tPage),
        });
        if (timeReport.column_definitions && timeCols.length === 0) {
          timeCols = timeReport.column_definitions.map((c: any) => Object.keys(c)[0]);
        }
        if (!timeReport.row_values || timeReport.row_values.length === 0) break;
        allTimeRows = allTimeRows.concat(timeReport.row_values);
        if (timeReport.row_values.length < 250) break;
        tPage++;
      }
      const timeColMap = new Map<string, number>();
      for (let i = 0; i < timeCols.length; i++) timeColMap.set(timeCols[i].toLowerCase(), i);
      const getTimeNum = (row: any[], col: string) => {
        const idx = timeColMap.get(col.toLowerCase());
        return idx != null ? Number(row[idx]) || 0 : 0;
      };
      const getTimeStr = (row: any[], col: string) => {
        const idx = timeColMap.get(col.toLowerCase());
        return idx != null ? String(row[idx] ?? "") : "";
      };
      let timeRevenue = 0;
      let timeCost = 0;
      let timeBilledRevenue = 0;
      let timeAgrCovered = 0;
      let totalHoursActual = 0;
      for (const row of allTimeRows) {
        const billableAmt = getTimeNum(row, "Billable_Amt");
        const hourlyCost = getTimeNum(row, "Hourly_Cost");
        const hoursActual = getTimeNum(row, "hours_actual");
        const agrAmtCovered = getTimeNum(row, "AgrAmtCovered");
        const invoiceFlag = row[timeColMap.get("invoice_flag") ?? -1];
        timeRevenue += billableAmt;
        timeCost += hourlyCost * hoursActual;
        timeBilledRevenue += (billableAmt - agrAmtCovered);
        timeAgrCovered += agrAmtCovered;
        totalHoursActual += hoursActual;
      }

      let allProdRows: any[][] = [];
      let prodCols: string[] = [];
      let pPage = 1;
      while (true) {
        const productReport = await apiGet("/system/reports/Product", {
          conditions: `company_recid = ${cwCompanyId} AND date_invoice >= [${dateFrom}] AND date_invoice <= [${dateTo}]`,
          pageSize: "250",
          page: String(pPage),
        });
        if (productReport.column_definitions && prodCols.length === 0) {
          prodCols = productReport.column_definitions.map((c: any) => Object.keys(c)[0]);
        }
        if (!productReport.row_values || productReport.row_values.length === 0) break;
        allProdRows = allProdRows.concat(productReport.row_values);
        if (productReport.row_values.length < 250) break;
        pPage++;
      }
      const prodColMap = new Map<string, number>();
      for (let i = 0; i < prodCols.length; i++) prodColMap.set(prodCols[i].toLowerCase(), i);
      const getProdNum = (row: any[], col: string) => {
        const idx = prodColMap.get(col.toLowerCase());
        return idx != null ? Number(row[idx]) || 0 : 0;
      };
      const getProdStr = (row: any[], col: string) => {
        const idx = prodColMap.get(col.toLowerCase());
        return idx != null ? String(row[idx] ?? "") : "";
      };
      let prodRevenue = 0;
      let prodCost = 0;
      let agrProdRevenue = 0;
      let agrProdCost = 0;
      let nonAgrProdRevenue = 0;
      let nonAgrProdCost = 0;
      for (const row of allProdRows) {
        const extCost = getProdNum(row, "Extended_Cost");
        const extPrice = getProdNum(row, "Extended_Price_Amount");
        const agr = getProdStr(row, "Agreement");
        prodRevenue += extPrice;
        prodCost += extCost;
        if (agr) {
          agrProdRevenue += extPrice;
          agrProdCost += extCost;
        } else {
          nonAgrProdRevenue += extPrice;
          nonAgrProdCost += extCost;
        }
      }

      const invoiceHeaders = await apiGet("/system/reports/InvoiceHeader", {
        conditions: `Company_RecID = ${cwCompanyId} AND Date_Invoice >= [${dateFrom}] AND Date_Invoice <= [${dateTo}]`,
        pageSize: "1000",
      });
      const ihCols = invoiceHeaders.column_definitions?.map((c: any) => Object.keys(c)[0]) || [];
      const getIHCol = (row: any[], col: string) => {
        const idx = ihCols.indexOf(col);
        return idx >= 0 ? row[idx] : null;
      };
      let ihAgrAmount = 0;
      let ihTimeAmount = 0;
      let ihMiscAmount = 0;
      let ihExpenseAmount = 0;
      let ihInvoiceAmount = 0;
      const ihBreakdown: any[] = [];
      for (const row of (invoiceHeaders.row_values || [])) {
        const agrAmt = Number(getIHCol(row, "AGR_Amount")) || 0;
        const timeAmt = Number(getIHCol(row, "Time_Amount")) || 0;
        const miscAmt = Number(getIHCol(row, "Misc_Amount")) || 0;
        const expAmt = Number(getIHCol(row, "Expense_Amount")) || 0;
        const invAmt = Number(getIHCol(row, "Invoice_Amount")) || 0;
        const invType = getIHCol(row, "Invoice_Type");
        const invNum = getIHCol(row, "Invoice_Number");
        ihAgrAmount += agrAmt;
        ihTimeAmount += timeAmt;
        ihMiscAmount += miscAmt;
        ihExpenseAmount += expAmt;
        ihInvoiceAmount += invAmt;
        ihBreakdown.push({ number: invNum, type: invType, total: invAmt, agrAmt, timeAmt, miscAmt, expAmt });
      }

      return res.json({
        period: `${dateFrom} to ${dateTo}`,
        cwTarget: { totalCost: 119688.72, totalRevenue: 238139.85, serviceCost: 14823.63, serviceRevenue: 25132.18, productsCost: 57327.75, productsRevenue: 73316.68, agreementsCost: 47537.34, agreementsRevenue: 139690.99 },
        invoiceApi: { agrInvoiceRevenue, stdInvoiceRevenue, miscInvoiceRevenue, progressInvoiceRevenue, totalInvoices: invoices.length },
        invoiceHeaderReport: { ihAgrAmount, ihTimeAmount, ihMiscAmount, ihExpenseAmount, ihInvoiceAmount, count: (invoiceHeaders.row_values || []).length },
        timeReport: { timeRevenue, timeCost, timeBilledRevenue, timeAgrCovered, totalHoursActual, rowCount: allTimeRows.length },
        productReport: { prodRevenue, prodCost, agrProdRevenue, agrProdCost, nonAgrProdRevenue, nonAgrProdCost, rowCount: allProdRows.length },
        derivedTotals: {
          revenueFromLineItems: timeBilledRevenue + prodRevenue,
          costFromLineItems: timeCost + prodCost,
        },
        expenseReport: await (async () => {
          try {
            const expData = await apiGet("/system/reports/Expense", {
              conditions: `Company_RecID = ${cwCompanyId} AND Date_Invoice >= [${dateFrom}] AND Date_Invoice <= [${dateTo}]`,
              pageSize: "1000",
            });
            const expCols = (expData.column_definitions || []).map((c: any) => Object.keys(c)[0]);
            const expColMap = new Map<string, number>();
            for (let i = 0; i < expCols.length; i++) expColMap.set(expCols[i].toLowerCase(), i);
            const getExpNum = (row: any[], col: string) => {
              const idx = expColMap.get(col.toLowerCase());
              return idx != null ? Number(row[idx]) || 0 : 0;
            };
            const getExpStr = (row: any[], col: string) => {
              const idx = expColMap.get(col.toLowerCase());
              return idx != null ? String(row[idx] ?? "") : "";
            };
            let totalExpCost = 0;
            let totalExpRevenue = 0;
            let agrExpCost = 0;
            let agrExpRevenue = 0;
            let nonAgrExpCost = 0;
            let nonAgrExpRevenue = 0;
            const sampleRows: any[] = [];
            for (const row of (expData.row_values || [])) {
              const cost = getExpNum(row, "Expense_Cost");
              const billAmt = getExpNum(row, "Bill_Amount");
              const agr = getExpStr(row, "Agreement");
              totalExpCost += cost;
              totalExpRevenue += billAmt;
              if (agr) { agrExpCost += cost; agrExpRevenue += billAmt; }
              else { nonAgrExpCost += cost; nonAgrExpRevenue += billAmt; }
              if (sampleRows.length < 3) {
                const desc = getExpStr(row, "Expense_Detail");
                const type = getExpStr(row, "Expense_Type");
                sampleRows.push({ type, desc, cost, billAmt, agreement: agr || null });
              }
            }
            return {
              columns: expCols,
              rowCount: (expData.row_values || []).length,
              totalExpCost, totalExpRevenue,
              agrExpCost, agrExpRevenue,
              nonAgrExpCost, nonAgrExpRevenue,
              sampleRows,
            };
          } catch (e: any) {
            return { error: e.message, columns: [] };
          }
        })(),
        invoiceBreakdown: invoiceBreakdown.slice(0, 5),
        ihBreakdown: ihBreakdown.slice(0, 5),
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message, stack: e.stack });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const parsed = loginUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Valid email and password required" });
      }

      const { email, password } = parsed.data;
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const valid = await bcrypt.compare(password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const token = crypto.randomBytes(32).toString("hex");
      tokenSessions.set(token, {
        userId: user.id,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
        pageAccess: user.pageAccess as Record<string, boolean> | null,
      });
      res.json({
        success: true,
        token,
        user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role, pageAccess: user.pageAccess },
      });
    } catch (err: any) {
      log(`Login error: ${err.message}`);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.get("/api/auth/check", (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      const session = tokenSessions.get(token);
      if (session) {
        return res.json({ authenticated: true, user: session });
      }
    }
    res.status(401).json({ authenticated: false });
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      tokenSessions.delete(authHeader.slice(7));
    }
    res.json({ success: true });
  });

  app.get("/api/users", requireAuth, requireAdmin, async (_req: Request, res: Response) => {
    try {
      const allUsers = await storage.getAllUsers();
      const sanitized = allUsers.map(u => ({
        id: u.id,
        email: u.email,
        displayName: u.displayName,
        role: u.role,
        pageAccess: u.pageAccess,
        createdAt: u.createdAt,
      }));
      res.json(sanitized);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/users", requireAuth, requireAdmin, async (req: Request, res: Response) => {
    try {
      const parsed = createUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.errors[0]?.message || "Invalid input" });
      }

      const existing = await storage.getUserByEmail(parsed.data.email);
      if (existing) {
        return res.status(409).json({ message: "A user with this email already exists" });
      }

      const passwordHash = await bcrypt.hash(parsed.data.password, 10);
      const user = await storage.createUser({
        email: parsed.data.email,
        displayName: parsed.data.displayName,
        passwordHash,
        role: parsed.data.role,
        pageAccess: req.body.pageAccess || null,
      });

      res.json({
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
        pageAccess: user.pageAccess,
        createdAt: user.createdAt,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/users/:id", requireAuth, requireAdmin, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid user ID" });

      const existing = await storage.getUserById(id);
      if (!existing) return res.status(404).json({ message: "User not found" });

      const currentUser = (req as any).user as TokenSession;
      if (currentUser.userId === id && req.body.role && req.body.role !== "admin" && existing.role === "admin") {
        return res.status(400).json({ message: "You cannot remove your own admin role" });
      }

      const updates: any = {};
      if (req.body.email) updates.email = req.body.email;
      if (req.body.displayName) updates.displayName = req.body.displayName;
      if (req.body.role) updates.role = req.body.role;
      if (req.body.password) {
        updates.passwordHash = await bcrypt.hash(req.body.password, 10);
      }
      if (req.body.pageAccess !== undefined) updates.pageAccess = req.body.pageAccess;

      const user = await storage.updateUser(id, updates);

      for (const [token, session] of tokenSessions.entries()) {
        if (session.userId === id) {
          session.email = user.email;
          session.displayName = user.displayName;
          session.role = user.role;
          session.pageAccess = user.pageAccess as Record<string, boolean> | null;
        }
      }

      res.json({
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
        pageAccess: user.pageAccess,
        createdAt: user.createdAt,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/users/:id", requireAuth, requireAdmin, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid user ID" });

      const currentUser = (req as any).user as TokenSession;
      if (currentUser.userId === id) {
        return res.status(400).json({ message: "You cannot delete your own account" });
      }

      await storage.deleteUser(id);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/auth/setup", async (req: Request, res: Response) => {
    try {
      const count = await storage.getUserCount();
      if (count > 0) {
        return res.status(400).json({ message: "Initial setup already completed" });
      }

      const parsed = createUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.errors[0]?.message || "Invalid input" });
      }

      const passwordHash = await bcrypt.hash(parsed.data.password, 10);
      const user = await storage.createUser({
        email: parsed.data.email,
        displayName: parsed.data.displayName,
        passwordHash,
        role: "admin",
      });

      const token = crypto.randomBytes(32).toString("hex");
      tokenSessions.set(token, {
        userId: user.id,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
        pageAccess: user.pageAccess as Record<string, boolean> | null,
      });
      res.json({
        success: true,
        token,
        user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role, pageAccess: user.pageAccess },
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/auth/needs-setup", async (_req: Request, res: Response) => {
    try {
      const count = await storage.getUserCount();
      res.json({ needsSetup: count === 0 });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/status", requireAuth, (_req: Request, res: Response) => {
    res.json({
      ninjaone: ninjaone.isConfigured(),
      huntress: huntress.isConfigured(),
      huntressSat: huntress.isSatConfigured(),
      connectwise: connectwise.isConfigured(),
    });
  });

  app.get("/api/organizations", requireAuth, async (_req: Request, res: Response) => {
    try {
      if (!ninjaone.isConfigured()) {
        return res.status(400).json({ message: "NinjaOne is not configured" });
      }
      const orgs = await ninjaone.getOrganizations();
      res.json(orgs);
    } catch (err: any) {
      log(`Organizations error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/huntress/organizations", requireAuth, async (_req: Request, res: Response) => {
    try {
      const { getOrganizations: huntressGetOrgs } = await import("./services/huntress.js");
      const orgs = await huntressGetOrgs();
      res.json(orgs);
    } catch (err: any) {
      log(`Huntress orgs error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/cipp/tenants", requireAuth, async (_req: Request, res: Response) => {
    try {
      const { isConfigured: cippConfigured, getTenants: cippGetTenants } = await import("./services/cipp.js");
      if (!cippConfigured()) return res.json([]);
      const tenants = await cippGetTenants();
      res.json(tenants);
    } catch (err: any) {
      log(`CIPP tenants error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/devices/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }

      if (!ninjaone.isConfigured()) {
        return res.json({
          totalDevices: 0,
          workstations: 0,
          servers: 0,
          deviceTypeCounts: {
            windowsDesktops: 0,
            windowsLaptops: 0,
            macDesktops: 0,
            macLaptops: 0,
            windowsServers: 0,
          },
          oldDevices: [],
          eolOsDevices: [],
          staleDevices: [],
          needsReplacementCount: 0,
          patchCompliancePercent: 100,
          pendingPatchCount: 0,
          installedPatchCount: 0,
          criticalAlerts: [],
        } satisfies DeviceHealthSummary);
      }

      const health = await ninjaone.getDeviceHealth(orgId);
      res.json(health);
    } catch (err: any) {
      log(`Device health error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/security/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }

      let orgName = `Organization ${orgId}`;
      try {
        if (ninjaone.isConfigured()) {
          const orgs = await ninjaone.getOrganizations();
          const org = orgs.find((o) => o.id === orgId);
          if (org) orgName = org.name;
        }
      } catch {}

      if (!huntress.isConfigured()) {
        return res.json({
          totalIncidents: 0,
          resolvedIncidents: 0,
          pendingIncidents: 0,
          recentIncidents: [],
          activeAgents: 0,
          managedAntivirusCount: 0,
          antivirusNotProtectedCount: 0,
          satCompletionPercent: null,
          phishingClickRate: null,
          satLearnerCount: null,
          satTotalUsers: null,
          satCoveragePercent: null,
          satModulesCompleted: null,
          satModulesAssigned: null,
          phishingCampaignCount: null,
          phishingCompromiseRate: null,
          phishingReportRate: null,
          recentPhishingCampaigns: [],
          satUnenrolledUsers: [],
          unprotectedAgents: [],
          identitiesMonitored: null,
          trendDirection: "stable",
        } satisfies SecuritySummary);
      }

      const security = await huntress.getSecuritySummary(orgName);
      res.json(security);
    } catch (err: any) {
      log(`Security error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/coverage-gap/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }

      let orgName = `Organization ${orgId}`;
      try {
        if (ninjaone.isConfigured()) {
          const orgs = await ninjaone.getOrganizations();
          const org = orgs.find((o) => o.id === orgId);
          if (org) orgName = org.name;
        }
      } catch {}

      if (!ninjaone.isConfigured() || !huntress.isConfigured()) {
        return res.json({ ninjaDevices: [], huntressAgents: [], missingFromHuntress: [], missingFromNinja: [] });
      }

      const ninjaDevices = await ninjaone.getDeviceNamesWithLastSeen(orgId);
      const huntressNames = await huntress.getAgentHostnames(orgName);

      const extractHostname = (name: string): string => {
        const parts = name.split(".");
        return parts[0].toLowerCase().replace(/[^a-z0-9-]/g, "");
      };
      const normalizeHostname = (name: string): string =>
        extractHostname(name).replace(/[^a-z0-9]/g, "");

      const ninjaSet = new Map<string, { name: string; lastSeen: string | null }>();
      for (const d of ninjaDevices) ninjaSet.set(normalizeHostname(d.name), d);

      const huntressSet = new Map<string, string>();
      for (const h of huntressNames) huntressSet.set(normalizeHostname(h), h);

      const missingFromHuntress = ninjaDevices
        .filter(d => !huntressSet.has(normalizeHostname(d.name)))
        .map(d => ({ name: extractHostname(d.name), lastSeen: d.lastSeen }));
      const missingFromNinja = huntressNames.filter(h => !ninjaSet.has(normalizeHostname(h)));

      log(`Coverage gap for "${orgName}": ${ninjaDevices.length} Ninja, ${huntressNames.length} Huntress, ${missingFromHuntress.length} missing from Huntress, ${missingFromNinja.length} missing from Ninja`);

      res.json({
        ninjaCount: ninjaDevices.length,
        huntressCount: huntressNames.length,
        missingFromHuntress,
        missingFromNinja,
      });
    } catch (err: any) {
      log(`Coverage gap error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/device-users/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }

      if (!ninjaone.isConfigured()) {
        return res.json({ devices: [] });
      }

      let orgName = `Organization ${orgId}`;
      try {
        const orgs = await ninjaone.getOrganizations();
        const org = orgs.find((o) => o.id === orgId);
        if (org) orgName = org.name;
      } catch {}

      const devices = await ninjaone.getDeviceUserMapping(orgId);

      if (huntress.isConfigured()) {
        try {
          const huntressHostnames = await huntress.getAgentHostnames(orgName);
          const huntressSet = new Set(huntressHostnames.map(h => h.toLowerCase().split(".")[0].replace(/[^a-z0-9-]/g, "")));
          for (const d of devices) {
            const normalizedHostname = d.hostname.toLowerCase().split(".")[0].replace(/[^a-z0-9-]/g, "");
            d.huntressProtected = huntressSet.has(normalizedHostname);
          }
        } catch (e: any) {
          log(`Device-user Huntress cross-ref error: ${e.message}`);
        }
      }

      res.json({ devices });
    } catch (err: any) {
      log(`Device-user mapping error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tickets/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }

      let orgName = `Organization ${orgId}`;
      try {
        if (ninjaone.isConfigured()) {
          const orgs = await ninjaone.getOrganizations();
          const org = orgs.find((o) => o.id === orgId);
          if (org) orgName = org.name;
        }
      } catch {}

      if (!connectwise.isConfigured()) {
        return res.json({
          totalTickets: 0,
          topCategories: [],
          recurringIssues: [],
          oldOpenTickets: [],
          monthlyVolume: [],
        } satisfies TicketSummary);
      }

      const tickets = await connectwise.getTicketSummary(orgName);
      res.json(tickets);
    } catch (err: any) {
      log(`Tickets error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/projects/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }

      let orgName = `Organization ${orgId}`;
      try {
        if (ninjaone.isConfigured()) {
          const orgs = await ninjaone.getOrganizations();
          const org = orgs.find((o) => o.id === orgId);
          if (org) orgName = org.name;
        }
      } catch {}

      if (!connectwise.isConfigured()) {
        return res.json({ completed: [], inProgress: [] });
      }

      const projects = await connectwise.getProjectItems(orgName);
      res.json(projects);
    } catch (err: any) {
      log(`Projects error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/projects/summarize", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { clientName, completed, inProgress } = req.body;
      if (!clientName) {
        return res.status(400).json({ message: "Client name is required" });
      }

      const { generateProjectSummary } = await import("./services/roadmap");
      const summary = await generateProjectSummary(clientName, completed || [], inProgress || []);
      res.json({ summary });
    } catch (err: any) {
      log(`Project summary error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/reports/mfa", requireAuth, requireEditor, upload.single("file"), (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const csvText = req.file.buffer.toString("utf-8").replace(/^\uFEFF/, "");
      const parsed = Papa.parse(csvText, { header: true, skipEmptyLines: true, transformHeader: (h: string) => h.trim() });

      if (parsed.errors.length > 0) {
        log(`MFA CSV parse warnings: ${JSON.stringify(parsed.errors.slice(0, 3))}`);
      }

      const getCol = (row: any, ...keys: string[]): string => {
        for (const key of keys) {
          if (row[key] !== undefined && row[key] !== null && row[key] !== "") return row[key].toString().trim();
        }
        return "";
      };

      const isYes = (val: string): boolean => {
        return ["yes", "true", "1"].includes(val.toLowerCase());
      };

      const isCACovered = (val: string): boolean => {
        const lower = val.toLowerCase();
        if (["not enforced", "no", "false", "0", ""].includes(lower)) return false;
        return lower.includes("enforced") || isYes(val);
      };

      const isSDCovered = (val: string): boolean => {
        return isYes(val);
      };

      const allRows = parsed.data as any[];
      const activeUsers = allRows.filter((row: any) => {
        const email = getCol(row, "UPN", "User Principal Name", "userPrincipalName", "email", "Email");
        if (!email) return false;
        const accountEnabled = getCol(row, "AccountEnabled", "Account Enabled", "accountEnabled");
        const licensed = getCol(row, "isLicensed", "IsLicensed", "Is Licensed");
        return isYes(accountEnabled) && isYes(licensed);
      });

      const users = activeUsers.map((row: any) => {
        const email = getCol(row, "UPN", "User Principal Name", "userPrincipalName", "email", "Email");
        const displayName = getCol(row, "Display Name", "DisplayName", "displayName", "name", "Name") || email.split("@")[0];

        const caRaw = getCol(row, "CoveredByCA", "coveredByCA", "Covered By CA");
        const sdRaw = getCol(row, "CoveredBySD", "coveredBySD", "Covered By SD");
        const perUserRaw = getCol(row, "PerUser", "perUser", "Per User", "Per User MFA").toLowerCase() || "disabled";
        const perUserEnabled = ["enabled", "enforced"].includes(perUserRaw);

        const coveredByCA = isCACovered(caRaw);
        const coveredBySD = isSDCovered(sdRaw);

        const isCovered = perUserEnabled || coveredByCA || coveredBySD;
        let coverageMethod: "perUser" | "conditionalAccess" | "securityDefaults" | null = null;
        if (coveredByCA) coverageMethod = "conditionalAccess";
        else if (coveredBySD) coverageMethod = "securityDefaults";
        else if (perUserEnabled) coverageMethod = "perUser";

        return {
          displayName,
          email,
          perUserMfa: perUserRaw,
          coveredByCA,
          coveredBySD,
          isCovered,
          coverageMethod,
        };
      });

      const coveredCount = users.filter((u: any) => u.isCovered).length;
      const uncoveredUsers = users.filter((u: any) => !u.isCovered);

      const report: MfaReport = {
        totalUsers: users.length,
        coveredCount,
        uncoveredCount: uncoveredUsers.length,
        coveredByPerUser: users.filter((u: any) => ["enabled", "enforced"].includes(u.perUserMfa)).length,
        coveredByCA: users.filter((u: any) => u.coveredByCA).length,
        coveredBySD: users.filter((u: any) => u.coveredBySD).length,
        uncoveredUsers,
        allUsers: users,
      };

      res.json(report);
    } catch (err: any) {
      log(`MFA report error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/reports/license", requireAuth, requireEditor, upload.single("file"), (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const MSRP_PRICES: Record<string, number> = {
        "microsoft 365 business basic": 6.00,
        "microsoft 365 business standard": 12.50,
        "microsoft 365 business premium": 22.00,
        "microsoft 365 apps for business": 8.25,
        "microsoft 365 e3": 36.00,
        "microsoft 365 e5": 57.00,
        "microsoft 365 f1": 2.25,
        "microsoft 365 f3": 8.00,
        "office 365 e1": 10.00,
        "office 365 e3": 23.00,
        "office 365 e5": 38.00,
        "exchange online (plan 1)": 4.00,
        "exchange online (plan 2)": 8.00,
        "exchange online kiosk": 2.00,
        "azure information protection plan 1": 2.00,
        "azure information protection premium p1": 2.00,
        "azure information protection premium p2": 5.00,
        "power bi pro": 10.00,
        "power bi premium per user": 20.00,
        "microsoft teams audio conferencing with dial-out to usa/can": 4.00,
        "microsoft teams essentials": 4.00,
        "microsoft defender for business": 3.00,
        "microsoft defender for endpoint plan 1": 3.00,
        "microsoft defender for endpoint plan 2": 5.20,
        "microsoft defender for office 365 plan 1": 2.00,
        "microsoft defender for office 365 plan 2": 5.00,
        "microsoft intune plan 1": 8.00,
        "azure ad premium p1": 6.00,
        "azure ad premium p2": 9.00,
        "entra id p1": 6.00,
        "entra id p2": 9.00,
        "visio plan 1": 5.00,
        "visio plan 2": 15.00,
        "project plan 1": 10.00,
        "project plan 3": 30.00,
        "project plan 5": 55.00,
        "microsoft copilot": 30.00,
      };

      const FREE_SKUS = [
        "rights management adhoc",
        "rights management service basic content protection",
        "common area phone",
        "microsoft power automate free",
        "microsoft power apps plan 2 trial",
        "azure active directory free",
      ];

      const getMsrp = (name: string): number => {
        const lower = name.toLowerCase().trim();
        if (MSRP_PRICES[lower] !== undefined) return MSRP_PRICES[lower];
        for (const [key, price] of Object.entries(MSRP_PRICES)) {
          if (lower.includes(key) || key.includes(lower)) return price;
        }
        return 0;
      };

      const isFreesku = (name: string): boolean => {
        const lower = name.toLowerCase().trim();
        return FREE_SKUS.some(f => lower.includes(f));
      };

      const csvText = req.file.buffer.toString("utf-8").replace(/^\uFEFF/, "");
      const parsed = Papa.parse(csvText, { header: true, skipEmptyLines: true, transformHeader: (h: string) => h.trim() });

      if (parsed.errors.length > 0) {
        log(`License CSV parse warnings: ${JSON.stringify(parsed.errors.slice(0, 3))}`);
      }

      const getCol = (row: any, ...keys: string[]): string => {
        for (const key of keys) {
          if (row[key] !== undefined && row[key] !== null && row[key] !== "") return row[key].toString().trim();
        }
        return "";
      };

      const allRows = parsed.data as any[];
      const licenses = allRows.map((row: any) => {
        const licenseName = getCol(row, "License", "Product Name", "productName", "Product", "SKU");
        const totalLicenses = parseInt(getCol(row, "TotalLicenses", "Total", "Purchased", "Assigned", "assignedCount") || "0") || 0;
        const quantityUsed = parseInt(getCol(row, "CountUsed", "Used", "quantityUsed", "Active") || "0") || 0;
        const quantityAvailable = parseInt(getCol(row, "CountAvailable", "Available") || "0") || 0;
        const wasted = quantityAvailable > 0 ? quantityAvailable : Math.max(0, totalLicenses - quantityUsed);
        const monthlyPricePerLicense = getMsrp(licenseName);
        const monthlyWastedCost = wasted * monthlyPricePerLicense;

        return { licenseName, totalLicenses, quantityUsed, quantityAvailable: wasted, wasted, monthlyPricePerLicense, monthlyWastedCost };
      }).filter((l: any) => l.licenseName && !isFreesku(l.licenseName));

      const totalWasted = licenses.reduce((sum: number, l: any) => sum + l.wasted, 0);
      const totalMonthlyWaste = licenses.reduce((sum: number, l: any) => sum + l.monthlyWastedCost, 0);

      const report: LicenseReport = {
        licenses,
        totalWasted,
        totalMonthlyWaste: Math.round(totalMonthlyWaste * 100) / 100,
        totalAnnualWaste: Math.round(totalMonthlyWaste * 12 * 100) / 100,
      };

      res.json(report);
    } catch (err: any) {
      log(`License report error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/reports/process-staging", requireAuth, requireEditor, (req: Request, res: Response) => {
    try {
      const { mfaReportData, licenseReportData } = req.body;
      const result: any = {};

      if (mfaReportData?.rawRows) {
        const getCol = (row: any, ...keys: string[]): string => {
          for (const key of keys) {
            if (row[key] !== undefined && row[key] !== null && row[key] !== "") return row[key].toString().trim();
          }
          return "";
        };
        const isYes = (val: string): boolean => ["yes", "true", "1"].includes(val.toLowerCase());
        const isCACovered = (val: string): boolean => {
          const lower = val.toLowerCase();
          if (["not enforced", "no", "false", "0", ""].includes(lower)) return false;
          return lower.includes("enforced") || isYes(val);
        };
        const isSDCovered = (val: string): boolean => isYes(val);

        const allRows = mfaReportData.rawRows as any[];
        const activeUsers = allRows.filter((row: any) => {
          const email = getCol(row, "UPN", "User Principal Name", "userPrincipalName", "email", "Email");
          if (!email) return false;
          const accountEnabled = getCol(row, "AccountEnabled", "Account Enabled", "accountEnabled");
          const licensed = getCol(row, "isLicensed", "IsLicensed", "Is Licensed");
          return isYes(accountEnabled) && isYes(licensed);
        });

        const users = activeUsers.map((row: any) => {
          const email = getCol(row, "UPN", "User Principal Name", "userPrincipalName", "email", "Email");
          const displayName = getCol(row, "Display Name", "DisplayName", "displayName", "name", "Name") || email.split("@")[0];
          const caRaw = getCol(row, "CoveredByCA", "coveredByCA", "Covered By CA");
          const sdRaw = getCol(row, "CoveredBySD", "coveredBySD", "Covered By SD");
          const perUserRaw = getCol(row, "PerUser", "perUser", "Per User", "Per User MFA").toLowerCase() || "disabled";
          const perUserEnabled = ["enabled", "enforced"].includes(perUserRaw);
          const coveredByCA = isCACovered(caRaw);
          const coveredBySD = isSDCovered(sdRaw);
          const isCovered = perUserEnabled || coveredByCA || coveredBySD;
          let coverageMethod: "perUser" | "conditionalAccess" | "securityDefaults" | null = null;
          if (coveredByCA) coverageMethod = "conditionalAccess";
          else if (coveredBySD) coverageMethod = "securityDefaults";
          else if (perUserEnabled) coverageMethod = "perUser";
          return { displayName, email, perUserMfa: perUserRaw, coveredByCA, coveredBySD, isCovered, coverageMethod };
        });

        const coveredCount = users.filter((u: any) => u.isCovered).length;
        const uncoveredUsers = users.filter((u: any) => !u.isCovered);
        result.mfaReport = {
          totalUsers: users.length,
          coveredCount,
          uncoveredCount: uncoveredUsers.length,
          coveredByPerUser: users.filter((u: any) => ["enabled", "enforced"].includes(u.perUserMfa)).length,
          coveredByCA: users.filter((u: any) => u.coveredByCA).length,
          coveredBySD: users.filter((u: any) => u.coveredBySD).length,
          uncoveredUsers,
          allUsers: users,
        };
      }

      if (licenseReportData?.rawRows) {
        const MSRP_PRICES: Record<string, number> = {
          "microsoft 365 business basic": 6.00, "microsoft 365 business standard": 12.50,
          "microsoft 365 business premium": 22.00, "microsoft 365 apps for business": 8.25,
          "microsoft 365 e3": 36.00, "microsoft 365 e5": 57.00,
          "microsoft 365 f1": 2.25, "microsoft 365 f3": 8.00,
          "office 365 e1": 10.00, "office 365 e3": 23.00, "office 365 e5": 38.00,
          "exchange online (plan 1)": 4.00, "exchange online (plan 2)": 8.00,
          "exchange online kiosk": 2.00, "microsoft teams audio conferencing with dial-out to usa/can": 4.00,
          "microsoft teams essentials": 4.00, "microsoft defender for business": 3.00,
          "microsoft defender for endpoint plan 1": 3.00, "microsoft defender for endpoint plan 2": 5.20,
          "microsoft defender for office 365 plan 1": 2.00, "microsoft defender for office 365 plan 2": 5.00,
          "microsoft intune plan 1": 8.00, "azure ad premium p1": 6.00, "azure ad premium p2": 9.00,
          "entra id p1": 6.00, "entra id p2": 9.00, "power bi pro": 10.00, "power bi premium per user": 20.00,
          "visio plan 1": 5.00, "visio plan 2": 15.00, "project plan 1": 10.00,
          "project plan 3": 30.00, "project plan 5": 55.00, "microsoft copilot": 30.00,
          "azure information protection plan 1": 2.00, "azure information protection premium p1": 2.00,
          "azure information protection premium p2": 5.00,
        };
        const FREE_SKUS = [
          "rights management adhoc", "rights management service basic content protection",
          "common area phone", "microsoft power automate free",
          "microsoft power apps plan 2 trial", "azure active directory free",
        ];
        const getMsrp = (name: string): number => {
          const lower = name.toLowerCase().trim();
          if (MSRP_PRICES[lower] !== undefined) return MSRP_PRICES[lower];
          for (const [key, price] of Object.entries(MSRP_PRICES)) {
            if (lower.includes(key) || key.includes(lower)) return price;
          }
          return 0;
        };
        const isFreesku = (name: string): boolean => {
          const lower = name.toLowerCase().trim();
          return FREE_SKUS.some(f => lower.includes(f));
        };
        const getCol = (row: any, ...keys: string[]): string => {
          for (const key of keys) {
            if (row[key] !== undefined && row[key] !== null && row[key] !== "") return row[key].toString().trim();
          }
          return "";
        };

        const allRows = licenseReportData.rawRows as any[];
        const licenses = allRows.map((row: any) => {
          const licenseName = getCol(row, "License", "Product Name", "productName", "Product", "SKU");
          const totalLicenses = parseInt(getCol(row, "TotalLicenses", "Total", "Purchased", "Assigned", "assignedCount") || "0") || 0;
          const quantityUsed = parseInt(getCol(row, "CountUsed", "Used", "quantityUsed", "Active") || "0") || 0;
          const quantityAvailable = parseInt(getCol(row, "CountAvailable", "Available") || "0") || 0;
          const wasted = quantityAvailable > 0 ? quantityAvailable : Math.max(0, totalLicenses - quantityUsed);
          const monthlyPricePerLicense = getMsrp(licenseName);
          const monthlyWastedCost = wasted * monthlyPricePerLicense;
          return { licenseName, totalLicenses, quantityUsed, quantityAvailable: wasted, wasted, monthlyPricePerLicense, monthlyWastedCost };
        }).filter((l: any) => l.licenseName && !isFreesku(l.licenseName));

        const totalWasted = licenses.reduce((sum: number, l: any) => sum + l.wasted, 0);
        const totalMonthlyWaste = licenses.reduce((sum: number, l: any) => sum + l.monthlyWastedCost, 0);
        result.licenseReport = {
          licenses,
          totalWasted,
          totalMonthlyWaste: Math.round(totalMonthlyWaste * 100) / 100,
          totalAnnualWaste: Math.round(totalMonthlyWaste * 12 * 100) / 100,
        };
      }

      res.json(result);
    } catch (err: any) {
      log(`Process staging report error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/roadmap/generate", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { clientName, ...data } = req.body;
      const analysis = await roadmap.generateRoadmap(clientName || "Client", data);
      res.json(analysis);
    } catch (err: any) {
      log(`Roadmap error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/export/summary", requireAuth, (req: Request, res: Response) => {
    try {
      const html = generateSummaryHtml(req.body);
      res.setHeader("Content-Type", "text/html");
      res.send(html);
    } catch (err: any) {
      log(`Export error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  function buildSnapshotMetrics(body: any) {
    const { orgId, orgName, deviceHealth, security, tickets, mfaReport, licenseReport, roadmap: roadmapData } = body;
    const mfaCoveragePct = mfaReport?.totalUsers > 0
      ? Math.round((mfaReport.coveredCount / mfaReport.totalUsers) * 100)
      : null;
    return {
      orgId,
      orgName,
      totalDevices: deviceHealth?.totalDevices ?? 0,
      workstations: deviceHealth?.workstations ?? 0,
      servers: deviceHealth?.servers ?? 0,
      needsReplacementCount: deviceHealth?.needsReplacementCount ?? 0,
      patchCompliancePercent: deviceHealth?.patchCompliancePercent ?? 100,
      pendingPatchCount: deviceHealth?.pendingPatchCount ?? 0,
      eolOsCount: deviceHealth?.eolOsDevices?.length ?? 0,
      staleDeviceCount: deviceHealth?.staleDevices?.length ?? 0,
      totalIncidents: security?.totalIncidents ?? 0,
      pendingIncidents: security?.pendingIncidents ?? 0,
      activeAgents: security?.activeAgents ?? 0,
      satLearnerCount: security?.satLearnerCount ?? null,
      satTotalUsers: security?.satTotalUsers ?? null,
      totalTickets: tickets?.totalTickets ?? 0,
      oldOpenTicketCount: tickets?.oldOpenTickets?.length ?? 0,
      mfaTotalUsers: mfaReport?.totalUsers ?? null,
      mfaCoveredCount: mfaReport?.coveredCount ?? null,
      mfaCoveragePercent: mfaCoveragePct,
      licenseTotalWasted: licenseReport?.totalWasted ?? null,
      licenseMonthlyWaste: licenseReport?.totalMonthlyWaste ?? null,
      licenseAnnualWaste: licenseReport?.totalAnnualWaste ?? null,
      roadmapItemCount: roadmapData?.items?.length ?? 0,
      urgentItemCount: roadmapData?.items?.filter((i: any) => i.priority === "urgent").length ?? 0,
    };
  }

  app.post("/api/tbr/save-draft", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { orgId, orgName, scheduleId, reviewDate } = req.body;
      if (!orgId || !orgName) {
        return res.status(400).json({ message: "Organization ID and name are required" });
      }

      const metrics = buildSnapshotMetrics(req.body);
      const fullData = {
        deviceHealth: req.body.deviceHealth || null,
        security: req.body.security || null,
        tickets: req.body.tickets || null,
        mfaReport: req.body.mfaReport || null,
        licenseReport: req.body.licenseReport || null,
        roadmap: req.body.roadmap || null,
        internalNotes: req.body.internalNotes || null,
        clientFeedback: req.body.clientFeedback || null,
        deviceUserInventory: req.body.deviceUserInventory || null,
      };

      const existingDraft = await storage.getDraftByOrg(orgId);

      if (existingDraft) {
        const result = await storage.updateTbrSnapshot(existingDraft.id, {
          ...metrics,
          status: "draft",
          fullData,
          scheduleId: scheduleId ? parseInt(scheduleId) : existingDraft.scheduleId,
          reviewDate: reviewDate || existingDraft.reviewDate || null,
        });
        log(`TBR draft updated for ${orgName} (orgId: ${orgId}), snapshot ID: ${result.id}`);
        res.json(result);
      } else {
        const snapshotData = {
          ...metrics,
          status: "draft",
          fullData,
          scheduleId: scheduleId ? parseInt(scheduleId) : null,
          reviewDate: reviewDate || null,
        };
        const parsed = insertTbrSnapshotSchema.safeParse(snapshotData);
        if (!parsed.success) {
          return res.status(400).json({ message: "Invalid snapshot data", errors: parsed.error.flatten().fieldErrors });
        }
        const result = await storage.createTbrSnapshot(parsed.data);
        log(`TBR draft saved for ${orgName} (orgId: ${orgId}), snapshot ID: ${result.id}`);
        res.json(result);
      }
    } catch (err: any) {
      log(`TBR save draft error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tbr/drafts", requireAuth, async (_req: Request, res: Response) => {
    try {
      const drafts = await storage.getAllDrafts();
      res.json(drafts);
    } catch (err: any) {
      log(`Get all drafts error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tbr/draft/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }
      const draft = await storage.getDraftByOrg(orgId);
      res.json({ draft: draft || null });
    } catch (err: any) {
      log(`TBR draft load error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/tbr/draft/:id", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid draft ID" });
      }
      await storage.deleteTbrSnapshot(id);
      res.json({ success: true });
    } catch (err: any) {
      log(`TBR draft delete error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/tbr/finalize", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { orgId, orgName, scheduleId, reviewDate } = req.body;
      if (!orgId || !orgName) {
        return res.status(400).json({ message: "Organization ID and name are required" });
      }

      const metrics = buildSnapshotMetrics(req.body);
      const fullData = {
        deviceHealth: req.body.deviceHealth || null,
        security: req.body.security || null,
        tickets: req.body.tickets || null,
        mfaReport: req.body.mfaReport || null,
        licenseReport: req.body.licenseReport || null,
        roadmap: req.body.roadmap || null,
        internalNotes: req.body.internalNotes || null,
        clientFeedback: req.body.clientFeedback || null,
        deviceUserInventory: req.body.deviceUserInventory || null,
      };

      const existingDraft = await storage.getDraftByOrg(orgId);

      let result;
      if (existingDraft) {
        result = await storage.updateTbrSnapshot(existingDraft.id, {
          ...metrics,
          status: "finalized",
          fullData,
          scheduleId: scheduleId ? parseInt(scheduleId) : existingDraft.scheduleId,
          reviewDate: reviewDate || existingDraft.reviewDate || null,
        });
      } else {
        const snapshotData = {
          ...metrics,
          status: "finalized",
          fullData,
          scheduleId: scheduleId ? parseInt(scheduleId) : null,
          reviewDate: reviewDate || null,
        };
        const parsed = insertTbrSnapshotSchema.safeParse(snapshotData);
        if (!parsed.success) {
          return res.status(400).json({ message: "Invalid snapshot data", errors: parsed.error.flatten().fieldErrors });
        }
        result = await storage.createTbrSnapshot(parsed.data);
      }

      if (result.scheduleId) {
        try {
          const schedule = await storage.getScheduleByOrg(orgId);
          if (schedule && schedule.id === result.scheduleId) {
            const now = new Date();
            const nextDate = new Date(now);
            nextDate.setMonth(nextDate.getMonth() + schedule.frequencyMonths);
            await storage.upsertSchedule({
              orgId: schedule.orgId,
              orgName: schedule.orgName,
              frequencyMonths: schedule.frequencyMonths,
              nextReviewDate: nextDate,
              lastReviewDate: now,
              notes: schedule.notes,
              reminderEmail: schedule.reminderEmail,
              leadEngineerEmail: schedule.leadEngineerEmail,
            });
            log(`Schedule ${schedule.id} updated: lastReviewDate=${now.toISOString()}, nextReviewDate=${nextDate.toISOString()}`);
          }
        } catch (schedErr: any) {
          log(`Warning: Failed to update schedule after finalization: ${schedErr.message}`);
        }
      }

      log(`TBR finalized for ${orgName} (orgId: ${orgId}), snapshot ID: ${result.id}, scheduleId: ${result.scheduleId || 'none'}`);
      res.json(result);
    } catch (err: any) {
      log(`TBR finalize error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/connectwise/ticket", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { snapshotId, companyName, followUpTasks, tbrDate } = req.body;
      if (!companyName || !followUpTasks || !Array.isArray(followUpTasks) || followUpTasks.length === 0) {
        return res.status(400).json({ message: "companyName and followUpTasks are required" });
      }
      if (!connectwise.isConfigured()) {
        return res.status(503).json({ message: "ConnectWise is not configured" });
      }

      const result = await connectwise.createFollowUpTicket(companyName, followUpTasks, tbrDate || new Date().toISOString().split("T")[0]);

      if (snapshotId) {
        await storage.updateTbrSnapshot(snapshotId, { cwTicketId: result.ticketId });
        log(`Saved CW ticket #${result.ticketId} to snapshot ${snapshotId}`);
      }

      res.json(result);
    } catch (err: any) {
      log(`ConnectWise ticket creation error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/tbr/unfinalize/:id", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid snapshot ID" });
      }
      const snapshot = await storage.getTbrSnapshotById(id);
      if (!snapshot) {
        return res.status(404).json({ message: "Snapshot not found" });
      }
      if (snapshot.status !== "finalized") {
        return res.status(400).json({ message: "Only finalized TBRs can be un-finalized" });
      }
      const existingDraft = await storage.getDraftByOrg(snapshot.orgId);
      if (existingDraft) {
        return res.status(409).json({ message: "A draft already exists for this client. Discard it first before un-finalizing a past review." });
      }
      const result = await storage.updateTbrSnapshot(id, { status: "draft" });
      log(`TBR un-finalized: snapshot ${id} for orgId ${snapshot.orgId}`);
      res.json(result);
    } catch (err: any) {
      log(`TBR un-finalize error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/export/snapshot/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid snapshot ID" });
      }
      const snapshot = await storage.getTbrSnapshotById(id);
      if (!snapshot) {
        return res.status(404).json({ message: "Snapshot not found" });
      }
      const fd = (snapshot.fullData as any) || {};
      const html = generateSummaryHtml({
        clientName: snapshot.orgName,
        deviceHealth: fd.deviceHealth || null,
        security: fd.security || null,
        tickets: fd.tickets || null,
        mfaReport: fd.mfaReport || null,
        licenseReport: fd.licenseReport || null,
        roadmap: fd.roadmap || null,
        previousSnapshot: null,
        deviceUserInventory: fd.deviceUserInventory || null,
      });
      res.setHeader("Content-Type", "text/html");
      res.send(html);
    } catch (err: any) {
      log(`Snapshot export error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tbr/history/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }
      const snapshots = await storage.getFinalizedSnapshotsByOrg(orgId);
      res.json(snapshots);
    } catch (err: any) {
      log(`TBR history error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tbr/snapshot/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid snapshot ID" });
      }
      const snapshot = await storage.getTbrSnapshotById(id);
      if (!snapshot) {
        return res.status(404).json({ message: "Snapshot not found" });
      }
      res.json(snapshot);
    } catch (err: any) {
      log(`TBR snapshot error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tbr/latest/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) {
        return res.status(400).json({ message: "Invalid organization ID" });
      }
      const latest = await storage.getLatestTbrSnapshot(orgId);
      const previous = await storage.getPreviousTbrSnapshot(orgId);
      res.json({ latest: latest || null, previous: previous || null });
    } catch (err: any) {
      log(`TBR latest error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/schedules", requireAuth, async (_req: Request, res: Response) => {
    try {
      const schedules = await storage.getAllSchedules();
      res.json(schedules);
    } catch (err: any) {
      log(`Schedules list error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/schedules/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) return res.status(400).json({ message: "Invalid org ID" });
      const schedule = await storage.getScheduleByOrg(orgId);
      res.json({ schedule: schedule || null });
    } catch (err: any) {
      log(`Schedule get error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/schedules", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { orgId, orgName, frequencyMonths, nextReviewDate, notes, reminderEmail, leadEngineerEmail } = req.body;
      if (!orgId || !orgName) return res.status(400).json({ message: "Org ID and name required" });
      const schedule = await storage.upsertSchedule({
        orgId,
        orgName,
        frequencyMonths: frequencyMonths || 6,
        nextReviewDate: nextReviewDate ? new Date(nextReviewDate) : null,
        lastReviewDate: null,
        notes: notes || null,
        reminderEmail: reminderEmail || null,
        leadEngineerEmail: leadEngineerEmail || null,
      });
      log(`Schedule upserted for ${orgName} (orgId: ${orgId})`);
      res.json(schedule);
    } catch (err: any) {
      log(`Schedule upsert error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/schedules/:id", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid schedule ID" });
      await storage.deleteSchedule(id);
      res.json({ success: true });
    } catch (err: any) {
      log(`Schedule delete error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/reminders/status", requireAuth, async (_req: Request, res: Response) => {
    try {
      const configured = isEmailConfigured();
      const dueSchedules = await storage.getSchedulesDueForReminder(3);
      res.json({
        emailConfigured: configured,
        pendingReminders: dueSchedules.length,
        provider: "smtp2go",
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/reminders/send-now", requireAuth, requireAdmin, async (_req: Request, res: Response) => {
    try {
      const dueSchedules = await storage.getSchedulesDueForReminder(3);
      if (dueSchedules.length === 0) {
        return res.json({ sent: 0, message: "No reminders due" });
      }
      const [smEmail, otherEmail] = await Promise.all([
        storage.getAppSetting("tbrEmailServiceManager"),
        storage.getAppSetting("tbrEmailOther"),
      ]);
      const globalEmails = [smEmail, otherEmail].filter(Boolean) as string[];
      let sent = 0;
      for (const schedule of dueSchedules) {
        if (!schedule.nextReviewDate) continue;
        const recipients = Array.from(new Set([
          ...(schedule.reminderEmail ? [schedule.reminderEmail] : []),
          ...(schedule.leadEngineerEmail ? [schedule.leadEngineerEmail] : []),
          ...globalEmails,
        ]));
        if (recipients.length === 0) continue;
        let anySuccess = false;
        for (const to of recipients) {
          const success = await sendReminderEmail({
            to,
            orgName: schedule.orgName,
            reviewDate: new Date(schedule.nextReviewDate),
            notes: schedule.notes,
          });
          if (success) anySuccess = true;
        }
        if (anySuccess) {
          await storage.markReminderSent(schedule.id);
          sent++;
        }
      }
      res.json({ sent, total: dueSchedules.length });
    } catch (err: any) {
      log(`Manual reminder send error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/tbr/all-finalized", requireAuth, async (_req: Request, res: Response) => {
    try {
      const snapshots = await storage.getAllFinalizedSnapshots();
      res.json(snapshots);
    } catch (err: any) {
      log(`All finalized snapshots error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/staging", requireAuth, async (_req: Request, res: Response) => {
    try {
      const all = await storage.getAllStaging();
      res.json(all);
    } catch (err: any) {
      log(`Staging list error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/staging/:orgId", requireAuth, async (req: Request, res: Response) => {
    try {
      const orgId = parseInt(req.params.orgId as string);
      if (isNaN(orgId)) return res.status(400).json({ message: "Invalid org ID" });
      const staging = await storage.getStagingByOrg(orgId);
      res.json({ staging: staging || null });
    } catch (err: any) {
      log(`Staging get error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/staging/save", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const { orgId, orgName, engineerNotes, serviceManagerNotes, warrantyData } = req.body;
      if (!orgId || !orgName) return res.status(400).json({ message: "Org ID and name required" });
      const existing = await storage.getStagingByOrg(orgId);
      const staging = await storage.upsertStaging({
        orgId,
        orgName,
        engineerNotes: engineerNotes ?? (existing as any)?.engineerNotes ?? null,
        serviceManagerNotes: serviceManagerNotes ?? (existing as any)?.serviceManagerNotes ?? null,
        mfaReportData: (existing as any)?.mfaReportData ?? null,
        licenseReportData: (existing as any)?.licenseReportData ?? null,
        mfaFileName: (existing as any)?.mfaFileName ?? null,
        licenseFileName: (existing as any)?.licenseFileName ?? null,
        warrantyData: warrantyData ?? (existing as any)?.warrantyData ?? null,
      });
      log(`Staging notes saved for ${orgName} (orgId: ${orgId})`);
      res.json(staging);
    } catch (err: any) {
      log(`Staging save error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/staging/upload-mfa", requireAuth, requireEditor, upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });
      const orgId = parseInt(req.body.orgId);
      const orgName = req.body.orgName;
      if (!orgId || !orgName) return res.status(400).json({ message: "Org ID and name required" });

      const csvText = req.file.buffer.toString("utf-8").replace(/^\uFEFF/, "");
      const parsed = Papa.parse(csvText, { header: true, skipEmptyLines: true, transformHeader: (h: string) => h.trim() });

      const existing = await storage.getStagingByOrg(orgId);
      const staging = await storage.upsertStaging({
        orgId,
        orgName,
        engineerNotes: (existing as any)?.engineerNotes ?? null,
        serviceManagerNotes: (existing as any)?.serviceManagerNotes ?? null,
        mfaReportData: { rawRows: parsed.data, headers: parsed.meta.fields },
        licenseReportData: (existing as any)?.licenseReportData ?? null,
        mfaFileName: req.file.originalname,
        licenseFileName: (existing as any)?.licenseFileName ?? null,
      });
      log(`Staging MFA CSV uploaded for ${orgName} (${parsed.data.length} rows)`);
      res.json(staging);
    } catch (err: any) {
      log(`Staging MFA upload error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/staging/upload-license", requireAuth, requireEditor, upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });
      const orgId = parseInt(req.body.orgId);
      const orgName = req.body.orgName;
      if (!orgId || !orgName) return res.status(400).json({ message: "Org ID and name required" });

      const csvText = req.file.buffer.toString("utf-8").replace(/^\uFEFF/, "");
      const parsed = Papa.parse(csvText, { header: true, skipEmptyLines: true, transformHeader: (h: string) => h.trim() });

      const existing = await storage.getStagingByOrg(orgId);
      const staging = await storage.upsertStaging({
        orgId,
        orgName,
        engineerNotes: (existing as any)?.engineerNotes ?? null,
        serviceManagerNotes: (existing as any)?.serviceManagerNotes ?? null,
        mfaReportData: (existing as any)?.mfaReportData ?? null,
        licenseReportData: { rawRows: parsed.data, headers: parsed.meta.fields },
        mfaFileName: (existing as any)?.mfaFileName ?? null,
        licenseFileName: req.file.originalname,
      });
      log(`Staging License CSV uploaded for ${orgName} (${parsed.data.length} rows)`);
      res.json(staging);
    } catch (err: any) {
      log(`Staging License upload error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/staging/:id", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid staging ID" });
      await storage.deleteStaging(id);
      res.json({ success: true });
    } catch (err: any) {
      log(`Staging delete error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  function generateMarginAnalysis(financials: any, engineers: any[]): MarginInsight[] {
    const insights: MarginInsight[] = [];
    const totalRev = financials.totalRevenue || 0;
    const laborCost = financials.laborCost || 0;
    const serviceLaborCost = financials.serviceLaborCost || 0;
    const projectLaborCost = financials.projectLaborCost || 0;
    const additionCost = financials.additionCost || 0;
    const projectProductCost = financials.projectProductCost || 0;
    const expenseCost = financials.expenseCost || 0;
    const msRev = financials.msLicensingRevenue || 0;
    const agreementRev = financials.agreementRevenue || 0;
    const projectRev = financials.projectRevenue || 0;
    const serviceHours = financials.serviceHours || 0;
    const projectHours = financials.projectHours || 0;
    const additions: AgreementAdditionInfo[] = financials.agreementAdditions || [];

    if (totalRev <= 0) return insights;

    const actionableAgrRev = agreementRev - msRev;
    const serviceMargin = actionableAgrRev > 0 ? ((actionableAgrRev - serviceLaborCost - additionCost) / actionableAgrRev) * 100 : 0;
    const projectMargin = projectRev > 0 ? ((projectRev - projectLaborCost - projectProductCost - expenseCost) / projectRev) * 100 : null;
    const actionableTotalRev = totalRev - msRev;
    const actionableTotalCost = laborCost + additionCost + projectProductCost + expenseCost;
    const overallMargin = actionableTotalRev > 0 ? ((actionableTotalRev - actionableTotalCost) / actionableTotalRev) * 100 : 0;

    if (actionableAgrRev > 0) {
      insights.push({
        type: serviceMargin < 50 ? "warning" : serviceMargin < 60 ? "suggestion" : "info",
        category: "labor",
        title: "Agreement Margin",
        detail: `Agreement revenue (excl. Microsoft): ${fmtD(actionableAgrRev)}/yr. Agreement labor: ${fmtD(serviceLaborCost)} (${serviceHours.toFixed(0)} hrs). Product costs: ${fmtD(additionCost)}. Agreement margin: ${serviceMargin.toFixed(1)}%.`,
        impact: serviceMargin < 50 ? `Agreement margin is below 50%. Review whether too many hours are being spent or if the agreement price needs adjusting.` : undefined,
      });
    }

    if (projectRev > 0 || projectLaborCost > 0) {
      if (projectRev > 0 && projectLaborCost > 0) {
        insights.push({
          type: projectMargin! < 50 ? "warning" : projectMargin! < 60 ? "suggestion" : "info",
          category: "project",
          title: "Project Margin",
          detail: `Project revenue: ${fmtD(projectRev)}. Project labor: ${fmtD(projectLaborCost)} (${projectHours.toFixed(0)} hrs)${projectProductCost > 0 ? `. Product costs: ${fmtD(projectProductCost)}` : ""}${expenseCost > 0 ? `. Expenses: ${fmtD(expenseCost)}` : ""}. Project margin: ${projectMargin!.toFixed(1)}%.`,
          impact: projectMargin! < 50 ? `Project work is below 50% margin. Check scoping, billing rates, and whether projects are being invoiced promptly.` : undefined,
        });
      } else if (projectLaborCost > 0 && projectRev === 0) {
        insights.push({
          type: "warning",
          category: "project",
          title: "Unbilled Project Work",
          detail: `${projectHours.toFixed(1)} project hours (${fmtD(projectLaborCost)} labor) with $0 project revenue. This eats directly into your overall margin.`,
        });
      }
    }

    if (msRev > 0) {
      insights.push({
        type: "info",
        category: "additions",
        title: "Microsoft Licensing (excluded from margin)",
        detail: `${fmtD(msRev)}/yr in Microsoft licensing at a fixed ~16% margin. Pass-through, excluded from actionable margin.`,
      });
    }

    const otherAdditions = additions.filter((a: any) => a.category === "other");
    const lowMarginOther = otherAdditions.filter((a: any) => a.margin < 20 && a.annualCost > 0);
    if (lowMarginOther.length > 0) {
      const names = lowMarginOther.slice(0, 3).map((a: any) => `${a.additionName} (${a.margin.toFixed(0)}%)`).join(", ");
      insights.push({
        type: "warning",
        category: "additions",
        title: "Low-Margin Third-Party Products",
        detail: `${names} — thin margins. Negotiate a better vendor rate or increase what you charge.`,
      });
    }

    if (engineers.length > 0 && laborCost > 0) {
      const topEng = engineers[0];
      const topPct = (topEng.totalCost / laborCost) * 100;
      if (topPct > 40 && topEng.hourlyCost >= 80) {
        const savingsEstimate = Math.round(topEng.totalHours * 0.3 * (topEng.hourlyCost - 40));
        insights.push({
          type: "suggestion",
          category: "labor",
          title: "Heavy Use of Expensive Engineer",
          detail: `${topEng.memberName} ($${topEng.hourlyCost}/hr) makes up ${topPct.toFixed(0)}% of total labor cost. Moving routine work to a cheaper engineer could save ~${fmtD(savingsEstimate)}/yr.`,
        });
      }
    }

    if (overallMargin < 43) {
      const gap = Math.round(actionableTotalRev * 0.52 - (actionableTotalRev - actionableTotalCost));
      insights.push({
        type: "warning",
        category: "overall",
        title: "Overall Margin Below 43%",
        detail: `Combined margin is ${overallMargin.toFixed(1)}% (excl. Microsoft). Close a ${fmtD(gap)}/yr gap to reach 52% — price increases, fewer hours, or cheaper staffing.`,
      });
    } else if (overallMargin < 52) {
      const gap = Math.round(actionableTotalRev * 0.52 - (actionableTotalRev - actionableTotalCost));
      insights.push({
        type: "suggestion",
        category: "overall",
        title: "Overall Margin Below 52% Target",
        detail: `Combined margin is ${overallMargin.toFixed(1)}%. Closing a ${fmtD(gap)}/yr gap would get you to 52%.`,
      });
    }

    return insights;
  }

  function fmtD(val: number): string {
    return "$" + Math.round(val).toLocaleString();
  }

  async function syncAccountsFromConnectWise(): Promise<{ results: any[]; removed: string[] }> {
    const cwClients = await connectwise.getManagedServicesClients();
    log(`[accounts-sync] Found ${cwClients.length} managed services clients from ConnectWise agreements`);

    const results = [];
    for (const client of cwClients) {
      const knownAgreementRevenue = client.agreementMonthlyRevenue * 12;
      let financials: any = { agreementRevenue: knownAgreementRevenue, projectRevenue: 0, totalRevenue: knownAgreementRevenue, grossMarginPercent: null, serviceMarginPercent: null, projectMarginPercent: null, laborCost: 0, serviceLaborCost: 0, projectLaborCost: 0, additionCost: 0, projectProductCost: 0, expenseCost: 0, msLicensingRevenue: 0, msLicensingCost: 0, totalCost: 0, serviceHours: 0, projectHours: 0, totalHours: 0, engineers: [], agreementAdditions: [] };
      try {
        financials = await connectwise.getCompanyFinancials(client.cwCompanyId);
      } catch (e: any) {
        log(`[accounts-sync] Skipping financials for ${client.companyName}: ${e.message}`);
      }

      const autoTier = financials.totalRevenue >= 60000 ? "A" : financials.totalRevenue >= 24000 ? "B" : "C";

      const marginInsights = generateMarginAnalysis(financials, financials.engineers || []);

      let arSummary = null;
      try {
        arSummary = await connectwise.getCompanyARSummary(client.cwCompanyId);
      } catch (e: any) {
        log(`[accounts-sync] Skipping AR for ${client.companyName}: ${e.message}`);
      }

      const account = await storage.upsertClientAccount({
        cwCompanyId: client.cwCompanyId,
        companyName: client.companyName,
        tier: autoTier,
        agreementRevenue: financials.agreementRevenue,
        projectRevenue: financials.projectRevenue,
        totalRevenue: financials.totalRevenue,
        laborCost: financials.laborCost,
        serviceLaborCost: financials.serviceLaborCost,
        projectLaborCost: financials.projectLaborCost,
        additionCost: financials.additionCost || 0,
        projectProductCost: financials.projectProductCost || 0,
        expenseCost: financials.expenseCost || 0,
        msLicensingRevenue: financials.msLicensingRevenue || 0,
        msLicensingCost: financials.msLicensingCost || 0,
        totalCost: financials.totalCost,
        serviceMarginPercent: financials.serviceMarginPercent,
        projectMarginPercent: financials.projectMarginPercent,
        grossMarginPercent: financials.grossMarginPercent,
        serviceHours: financials.serviceHours,
        projectHours: financials.projectHours,
        totalHours: financials.totalHours,
        engineerBreakdown: financials.engineers,
        agreementAdditions: financials.agreementAdditions || [],
        marginAnalysis: marginInsights,
        arSummary: arSummary,
        agreementTypes: client.agreementTypes.join(", "),
        lastSyncedAt: new Date(),
      });
      results.push(account);
    }

    // Prune accounts that are no longer in the CW "Client" list
    const freshCwIds = new Set(cwClients.map(c => c.cwCompanyId));
    const allExisting = await storage.getAllClientAccounts();
    const removed: string[] = [];
    for (const acct of allExisting) {
      if (!freshCwIds.has(acct.cwCompanyId)) {
        await storage.deleteClientAccount(acct.id);
        log(`[accounts-sync] Pruned "${acct.companyName}" (cwId ${acct.cwCompanyId}) — no longer an active CW Client`);
        removed.push(acct.companyName);
      }
    }
    if (removed.length) log(`[accounts-sync] Removed ${removed.length} account(s): ${removed.join(", ")}`);

    return { results, removed };
  }

  async function syncArOnlyClients(): Promise<number> {
    const allAgreementClients = await connectwise.getAllAgreementClients();
    const managedAccounts = await storage.getAllClientAccounts();
    const managedCwIds = new Set(managedAccounts.map(a => a.cwCompanyId));

    const arOnlyCompanies = allAgreementClients.filter(c => !managedCwIds.has(c.cwCompanyId));
    log(`[ar-sync] Found ${arOnlyCompanies.length} additional agreement clients (non-managed-services)`);

    let synced = 0;
    for (const client of arOnlyCompanies) {
      let arSummary = null;
      try {
        arSummary = await connectwise.getCompanyARSummary(client.cwCompanyId);
      } catch (e: any) {
        log(`[ar-sync] Skipping AR for ${client.companyName}: ${e.message}`);
      }

      await storage.upsertArOnlyClient({
        cwCompanyId: client.cwCompanyId,
        companyName: client.companyName,
        agreementTypes: client.agreementTypes.join(", "),
        agreementMonthlyRevenue: client.agreementMonthlyRevenue,
        arSummary: arSummary,
        lastSyncedAt: new Date(),
      });
      synced++;
    }
    return synced;
  }

  const AUTO_SYNC_INTERVAL_MS = 6 * 60 * 60 * 1000;
  let autoSyncRunning = false;

  async function runAutoSync() {
    if (autoSyncRunning) return;
    if (!connectwise.isConfigured()) return;
    autoSyncRunning = true;
    try {
      log("[accounts-sync] Starting automatic sync...");
      const { results, removed } = await syncAccountsFromConnectWise();
      log(`[accounts-sync] Auto-sync complete: ${results.length} accounts updated, ${removed.length} removed`);
      const arOnlyCount = await syncArOnlyClients();
      log(`[ar-sync] AR-only sync complete: ${arOnlyCount} additional clients updated`);
    } catch (err: any) {
      log(`[accounts-sync] Auto-sync error: ${err.message}`);
    } finally {
      autoSyncRunning = false;
    }
  }

  setTimeout(() => runAutoSync(), 30000);
  setInterval(() => runAutoSync(), AUTO_SYNC_INTERVAL_MS);
  log(`[accounts-sync] Scheduled automatic sync every ${AUTO_SYNC_INTERVAL_MS / 3600000} hours`);

  app.get("/api/accounts/sync", requireAuth, requireEditor, async (_req: Request, res: Response) => {
    try {
      if (!connectwise.isConfigured()) {
        return res.status(503).json({ message: "ConnectWise is not configured" });
      }

      const { results, removed } = await syncAccountsFromConnectWise();
      const arOnlyCount = await syncArOnlyClients();
      res.json({ synced: results.length, removed: removed.length, removedNames: removed, arOnlySynced: arOnlyCount, accounts: results });
    } catch (err: any) {
      log(`[accounts-sync] Manual sync error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/receivables/clients", requireAuth, async (_req: Request, res: Response) => {
    try {
      const managedAccounts = await storage.getAllClientAccounts();
      const arOnlyAccounts = await storage.getAllArOnlyClients();

      // Deduplicate: if a company appears in both managed and AR-only tables, prefer managed
      const managedCwIds = new Set(managedAccounts.map(a => a.cwCompanyId).filter(Boolean));

      const combined = [
        ...managedAccounts.map(a => ({
          id: a.id,
          cwCompanyId: a.cwCompanyId,
          companyName: a.companyName,
          agreementTypes: a.agreementTypes,
          arSummary: a.arSummary,
          lastSyncedAt: a.lastSyncedAt,
          tier: (a as any).tierOverride || a.tier,
          totalRevenue: a.totalRevenue,
          source: "managed" as const,
        })),
        ...arOnlyAccounts
          .filter(a => !managedCwIds.has(a.cwCompanyId))
          .map(a => ({
            id: a.id + 100000,
            cwCompanyId: a.cwCompanyId,
            companyName: a.companyName,
            agreementTypes: a.agreementTypes,
            arSummary: a.arSummary,
            lastSyncedAt: a.lastSyncedAt,
            tier: null,
            totalRevenue: (a.agreementMonthlyRevenue || 0) * 12,
            source: "agreement-only" as const,
          })),
      ];

      res.json(combined);
    } catch (err: any) {
      log(`[receivables] Error fetching clients: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/receivables/sync", requireAuth, requireEditor, async (_req: Request, res: Response) => {
    try {
      if (!connectwise.isConfigured()) {
        return res.status(503).json({ message: "ConnectWise is not configured" });
      }
      const arOnlyCount = await syncArOnlyClients();
      res.json({ synced: arOnlyCount });
    } catch (err: any) {
      log(`[ar-sync] Manual AR sync error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/accounts/:id/ar-refresh", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const accounts = await storage.getAllClientAccounts();
      const acct = accounts.find(a => a.id === id);
      if (!acct) return res.status(404).json({ message: "Account not found" });

      const arSummary = await connectwise.getCompanyARSummary(acct.cwCompanyId);
      if (arSummary) {
        await storage.upsertClientAccount({ ...acct, arSummary, lastSyncedAt: new Date() } as any);
      }
      res.json(arSummary || { error: "No AR data available" });
    } catch (err: any) {
      log(`[ar] Refresh error for account ${req.params.id}: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/accounts", requireAuth, async (_req: Request, res: Response) => {
    try {
      const accounts = await storage.getAllClientAccounts();
      const schedules = await storage.getAllSchedules();
      const allFinalized = await storage.getAllFinalizedSnapshots();

      const now = new Date();
      const sixMonthsAgo = new Date(now);
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      const twelveMonthsAhead = new Date(now);
      twelveMonthsAhead.setMonth(twelveMonthsAhead.getMonth() + 12);

      const enriched = accounts.map((acct) => {
        const schedule = schedules.find(s => s.orgName.toLowerCase().trim() === acct.companyName.toLowerCase().trim());
        const snapshots = allFinalized
          .filter(s => s.orgName.toLowerCase().trim() === acct.companyName.toLowerCase().trim())
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

        const lastTbr = snapshots[0] || null;
        const lastTbrDate = lastTbr ? (lastTbr.reviewDate || new Date(lastTbr.createdAt).toISOString().split("T")[0]) : null;
        const rawNextDate = schedule?.nextReviewDate ? new Date(schedule.nextReviewDate) : null;
        const nextTbrDate = rawNextDate && rawNextDate >= now && rawNextDate <= twelveMonthsAhead
          ? rawNextDate.toISOString().split("T")[0]
          : null;
        const freq = schedule?.frequencyMonths || null;

        const hadRecentTbr = lastTbr && new Date(lastTbr.createdAt) > sixMonthsAgo;
        const hasScheduled = !!nextTbrDate;

        let tbrStatus: "green" | "yellow" | "scheduled" | "red";
        let tbrStatusReason: string;

        if (hadRecentTbr && hasScheduled) {
          tbrStatus = "green";
          tbrStatusReason = "On track";
        } else if (hadRecentTbr && !hasScheduled) {
          tbrStatus = "yellow";
          tbrStatusReason = "No next review scheduled";
        } else if (!hadRecentTbr && hasScheduled) {
          tbrStatus = "scheduled";
          tbrStatusReason = "Overdue but TBR is scheduled";
        } else if (snapshots.length > 0) {
          tbrStatus = "yellow";
          tbrStatusReason = "Overdue — no recent review or schedule";
        } else {
          tbrStatus = "red";
          tbrStatusReason = "Never reviewed — no TBR on record";
        }

        const needsAnalysis = !acct.marginAnalysis && acct.totalRevenue && acct.totalRevenue > 0;
        let marginAnalysis = acct.marginAnalysis;
        if (needsAnalysis) {
          marginAnalysis = generateMarginAnalysis({
            totalRevenue: acct.totalRevenue,
            laborCost: acct.laborCost || 0,
            serviceLaborCost: (acct as any).serviceLaborCost || 0,
            projectLaborCost: (acct as any).projectLaborCost || 0,
            additionCost: acct.additionCost || 0,
            msLicensingRevenue: (acct as any).msLicensingRevenue || 0,
            msLicensingCost: (acct as any).msLicensingCost || 0,
            totalCost: acct.totalCost || 0,
            agreementRevenue: acct.agreementRevenue || 0,
            projectRevenue: acct.projectRevenue || 0,
            totalHours: acct.totalHours || 0,
            serviceHours: acct.serviceHours || 0,
            projectHours: acct.projectHours || 0,
            agreementAdditions: acct.agreementAdditions || [],
          }, (acct.engineerBreakdown as any[]) || []);
        }

        return {
          ...acct,
          marginAnalysis,
          lastTbrDate,
          nextTbrDate,
          tbrStatus,
          tbrStatusReason,
          effectiveTier: acct.tierOverride || acct.tier,
          scheduleFrequency: freq,
        };
      });

      res.json(enriched);
    } catch (err: any) {
      log(`Accounts list error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/accounts/:id/tier", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid account ID" });
      const { tier } = req.body;
      if (!tier || !["A", "B", "C"].includes(tier)) {
        return res.status(400).json({ message: "Tier must be A, B, or C" });
      }
      const result = await storage.updateClientAccountTier(id, tier);
      res.json(result);
    } catch (err: any) {
      log(`Account tier update error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/clients/:id/stack", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid account ID" });
      const accounts = await storage.getAllClientAccounts();
      const account = accounts.find(a => a.id === id);
      if (!account) return res.status(404).json({ message: "Account not found" });
      const current: any = account.stackCompliance || {};
      const updates = req.body || {};
      const merged = { ...current, ...updates, lastRefreshed: new Date().toISOString() };
      const result = await storage.updateClientStackCompliance(id, merged);
      res.json(result);
    } catch (err: any) {
      log(`Stack compliance update error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/clients/:id/tbr-invite", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid account ID" });
      const { invited } = req.body as { invited: boolean };
      const invitedAt = invited ? new Date() : null;
      const result = await storage.updateClientTbrInvite(id, invitedAt);
      res.json(result);
    } catch (err: any) {
      log(`TBR invite update error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  // In-memory bulk refresh progress state
  const bulkRefreshJob = {
    active: false,
    total: 0,
    completed: 0,
    currentClient: "",
    startedAt: null as string | null,
  };

  app.get("/api/clients/stack/refresh-progress", requireAuth, (_req: Request, res: Response) => {
    res.json({ ...bulkRefreshJob });
  });

  app.post("/api/clients/stack/refresh-all", requireAuth, async (req: Request, res: Response) => {
    if (bulkRefreshJob.active) {
      return res.json({ started: false, count: bulkRefreshJob.total, alreadyRunning: true });
    }
    try {
      const accounts = await storage.getAllClientAccounts();
      const managed = accounts.filter(a => a.tier && ["A", "B", "C"].includes(a.tier));
      const mappings = await storage.getAllClientMappings();
      bulkRefreshJob.active = true;
      bulkRefreshJob.total = managed.length;
      bulkRefreshJob.completed = 0;
      bulkRefreshJob.currentClient = "";
      bulkRefreshJob.startedAt = new Date().toISOString();
      res.json({ started: true, count: managed.length });
      (async () => {
        log(`Bulk stack refresh: pre-fetching org lists...`);
        let ninjaOrgs: any[] = [];
        let huntressOrgs: any[] = [];
        let cippTenants: any[] = [];
        try { ninjaOrgs = await ninjaone.getOrganizations(); log(`Bulk: got ${ninjaOrgs.length} Ninja orgs`); }
        catch (e: any) { log(`Bulk: Ninja fetch failed: ${e.message}`); }
        try { huntressOrgs = await huntress.getOrganizations(); log(`Bulk: got ${huntressOrgs.length} Huntress orgs`); }
        catch (e: any) { log(`Bulk: Huntress fetch failed: ${e.message}`); }
        const { isConfigured: cippConfigured, getTenants: cippGetTenants } = await import("./services/cipp.js");
        if (cippConfigured()) {
          try { cippTenants = await cippGetTenants(); log(`Bulk: got ${cippTenants.length} CIPP tenants`); }
          catch (e: any) { log(`Bulk: CIPP fetch failed: ${e.message}`); }
        }
        const prefetched = { ninjaOrgs, huntressOrgs, cippTenants };
        let ok = 0;
        for (const account of managed) {
          bulkRefreshJob.currentClient = account.companyName;
          try {
            const mapping = mappings.find(m => m.cwCompanyId === account.cwCompanyId);
            const updated = await refreshStackForAccount(account, mapping, prefetched);
            await storage.updateClientStackCompliance(account.id, updated);
            ok++;
          } catch (e: any) {
            log(`Bulk refresh error for ${account.companyName}: ${e.message}`);
          }
          bulkRefreshJob.completed++;
          await new Promise(r => setTimeout(r, 100));
        }
        log(`Bulk stack refresh complete: ${ok}/${managed.length} accounts updated`);
        bulkRefreshJob.active = false;
        bulkRefreshJob.currentClient = "";
      })().catch(e => {
        log(`Bulk refresh fatal: ${e.message}`);
        bulkRefreshJob.active = false;
      });
    } catch (err: any) {
      bulkRefreshJob.active = false;
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/clients/:id/stack/refresh", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id as string);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid account ID" });

      const accounts = await storage.getAllClientAccounts();
      const account = accounts.find(a => a.id === id);
      if (!account) return res.status(404).json({ message: "Account not found" });

      const mappings = await storage.getAllClientMappings();
      const mapping = mappings.find(m => m.cwCompanyId === account.cwCompanyId);

      const updated = await refreshStackForAccount(account, mapping);
      const result = await storage.updateClientStackCompliance(id, updated);
      res.json(result);
    } catch (err: any) {
      log(`Stack refresh error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/client-mappings", requireAuth, async (_req: Request, res: Response) => {
    try {
      const mappings = await storage.getAllClientMappings();
      res.json(mappings);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/client-mappings/:cwCompanyId", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const cwCompanyId = parseInt(req.params.cwCompanyId as string);
      if (isNaN(cwCompanyId)) return res.status(400).json({ message: "Invalid company ID" });
      const data = { ...req.body, cwCompanyId };
      const result = await storage.upsertClientMapping(data);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/dropsuite/import-csv", requireAuth, requireEditor, async (req: Request, res: Response) => {
    try {
      const rows: Array<{ companyName: string; dropsuiteUserId: string }> = req.body.rows || [];
      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).json({ message: "rows array is required" });
      }
      const allAccounts = await storage.getAllClientAccounts();
      const allMappings = await storage.getAllClientMappings();
      const results: Array<{ companyName: string; status: string; cwCompanyId?: number }> = [];

      function normName(s: string) {
        return s.toLowerCase()
          .replace(/\[.*?\]/g, "")
          .replace(/&/g, " and ")
          .replace(/\b(inc|llc|pllc|corp|ltd|co|group|services|solutions|tech|technologies|consulting|associates|management|systems|partners|company|international|properties|enterprises|law|legal|psc|pc|dds|cpa|md|dvm)\b/g, " ")
          .replace(/[^a-z0-9\s]/g, " ")
          .replace(/\s+/g, " ").trim();
      }

      for (const row of rows) {
        if (!row.companyName || !row.dropsuiteUserId) {
          results.push({ companyName: row.companyName || "(missing)", status: "skipped: missing name or user ID" });
          continue;
        }
        await storage.upsertDropsuiteAccount(row.dropsuiteUserId, row.companyName);
        const normTarget = normName(row.companyName);
        const tokens = normTarget.split(" ").filter(t => t.length > 2);

        let account = allAccounts.find(a => normName(a.companyName) === normTarget);
        if (!account) {
          account = allAccounts.find(a => {
            const n = normName(a.companyName);
            return n.includes(normTarget) || normTarget.includes(n);
          });
        }
        if (!account && tokens.length > 0) {
          account = allAccounts.find(a => {
            const aToks = normName(a.companyName).split(" ").filter(t => t.length > 2);
            if (aToks.length === 0) return false;
            const shorter = tokens.length <= aToks.length ? tokens : aToks;
            const longer = tokens.length <= aToks.length ? aToks : tokens;
            const hits = shorter.filter(t => longer.some(lt => lt === t || lt.startsWith(t) || t.startsWith(lt))).length;
            return hits >= Math.ceil(shorter.length * 0.75);
          });
        }
        if (!account) {
          results.push({ companyName: row.companyName, status: "not found in ConnectWise accounts" });
          continue;
        }
        const existing = allMappings.find(m => m.cwCompanyId === account!.cwCompanyId);
        await storage.upsertClientMapping({
          cwCompanyId: account.cwCompanyId,
          companyName: account.companyName,
          ninjaOrgId: existing?.ninjaOrgId ?? null,
          huntressOrgId: existing?.huntressOrgId ?? null,
          cippTenantId: existing?.cippTenantId ?? null,
          dropsuiteUserId: row.dropsuiteUserId,
          notes: existing?.notes ?? null,
        });
        const currentStack: any = account.stackCompliance || {};
        const updatedStack = {
          ...currentStack,
          dropSuite: true,
          dropsuiteNeedsMapping: false,
          lastRefreshed: currentStack.lastRefreshed ?? null,
          manualOverrides: currentStack.manualOverrides ?? {},
        };
        await storage.updateClientStackCompliance(account.id, updatedStack);
        results.push({ companyName: row.companyName, status: "mapped", cwCompanyId: account.cwCompanyId });
      }

      res.json({ results, total: rows.length, mapped: results.filter(r => r.status === "mapped").length });
    } catch (err: any) {
      log(`DropSuite CSV import error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/dropsuite/accounts", requireAuth, async (_req: Request, res: Response) => {
    try {
      const accounts = await storage.getAllDropsuiteAccounts();
      res.json(accounts);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/app-settings", requireAuth, async (_req: Request, res: Response) => {
    try {
      const [smEmail, otherEmail] = await Promise.all([
        storage.getAppSetting("tbrEmailServiceManager"),
        storage.getAppSetting("tbrEmailOther"),
      ]);
      res.json({
        tbrEmailServiceManager: smEmail ?? "",
        tbrEmailOther: otherEmail ?? "",
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/app-settings", requireAuth, requireAdmin, async (req: Request, res: Response) => {
    try {
      const { tbrEmailServiceManager, tbrEmailOther } = req.body;
      await Promise.all([
        storage.setAppSetting("tbrEmailServiceManager", tbrEmailServiceManager ?? ""),
        storage.setAppSetting("tbrEmailOther", tbrEmailOther ?? ""),
      ]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/sales/quotes", requireAuth, async (_req: Request, res: Response) => {
    try {
      const { getQuotesSummary, isConfigured: quoterConfigured } = await import("./services/quoter.js");
      if (!quoterConfigured()) {
        return res.status(503).json({ message: "Quoter not configured" });
      }
      const summary = await getQuotesSummary();
      res.json(summary);
    } catch (err: any) {
      log(`Quoter quotes error: ${err.message}`);
      res.status(500).json({ message: err.message });
    }
  });

  return httpServer;
}
