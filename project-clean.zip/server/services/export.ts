import fs from "fs";
import path from "path";
import type {
  DeviceHealthSummary,
  SecuritySummary,
  TicketSummary,
  MfaReport,
  LicenseReport,
  RoadmapAnalysis,
  TbrSnapshot,
  DeviceUserEntry,
} from "@shared/schema";

let _logoCache: string | null = null;
function getLogoBase64(): string {
  if (_logoCache) return _logoCache;
  try {
    const logoPath = path.resolve("server/assets/pelycon-logo.png");
    _logoCache = fs.readFileSync(logoPath).toString("base64");
  } catch {
    _logoCache = "";
  }
  return _logoCache;
}

function trendBadge(current: number, previous: number | null | undefined, higherIsBetter: boolean): string {
  if (previous === null || previous === undefined) return "";
  const diff = current - previous;
  if (diff === 0) return "";
  const improved = higherIsBetter ? diff > 0 : diff < 0;
  const color = improved ? "#16a34a" : "#dc2626";
  const bg = improved ? "#f0fdf4" : "#fef2f2";
  const arrow = improved ? "&#9650;" : "&#9660;";
  const sign = diff > 0 ? "+" : "";
  const val = typeof current === "number" && current % 1 !== 0 ? diff.toFixed(1) : diff.toString();
  return ` <span style="display:inline-block;font-size:10px;color:${color};background:${bg};padding:1px 6px;border-radius:3px;margin-left:4px;vertical-align:middle">${arrow} ${sign}${val}</span>`;
}

function trendPctBadge(current: number | null | undefined, previous: number | null | undefined, higherIsBetter: boolean): string {
  if (current === null || current === undefined || previous === null || previous === undefined) return "";
  const diff = current - previous;
  if (Math.abs(diff) < 0.5) return "";
  const improved = higherIsBetter ? diff > 0 : diff < 0;
  const color = improved ? "#16a34a" : "#dc2626";
  const bg = improved ? "#f0fdf4" : "#fef2f2";
  const arrow = improved ? "&#9650;" : "&#9660;";
  const sign = diff > 0 ? "+" : "";
  return ` <span style="display:inline-block;font-size:10px;color:${color};background:${bg};padding:1px 6px;border-radius:3px;margin-left:4px;vertical-align:middle">${arrow} ${sign}${Math.round(diff)}%</span>`;
}

function goodBad(isGood: boolean, goodText: string, badText: string): string {
  if (isGood) {
    return `<div class="item good"><span class="icon">&#10003;</span> ${goodText}</div>`;
  }
  return `<div class="item attention"><span class="icon">&#9888;</span> ${badText}</div>`;
}

function buildSection(title: string, subtitle: string, items: string[]): string {
  if (items.length === 0) return "";
  const header = `<div class="section-header"><h2>${title}</h2><span class="subtitle">${subtitle}</span></div>`;
  const first = items[0];
  const rest = items.slice(1).join("\n");
  return `
    <div class="section">
      <div class="section-top">${header}${first}</div>
      ${rest}
    </div>`;
}

export function generateSummaryHtml(data: {
  clientName: string;
  deviceHealth?: DeviceHealthSummary | null;
  security?: SecuritySummary | null;
  tickets?: TicketSummary | null;
  mfaReport?: MfaReport | null;
  licenseReport?: LicenseReport | null;
  roadmap?: RoadmapAnalysis | null;
  previousSnapshot?: TbrSnapshot | null;
  deviceUserInventory?: DeviceUserEntry[] | null;
}): string {
  const today = new Date().toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  const nextTbr = new Date();
  nextTbr.setMonth(nextTbr.getMonth() + 6);
  const nextTbrStr = nextTbr.toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  const prev = data.previousSnapshot;

  let sections = "";

  // === EXECUTIVE SNAPSHOT (quick status-at-a-glance) ===
  const snapItems: { label: string; value: string; status: "good" | "warn" | "neutral" }[] = [];

  if (data.security) {
    snapItems.push({
      label: "Security Incidents",
      value: data.security.pendingIncidents === 0 ? "None pending" : `${data.security.pendingIncidents} pending`,
      status: data.security.pendingIncidents === 0 ? "good" : "warn",
    });
  }
  if (data.mfaReport) {
    const pct = data.mfaReport.totalUsers > 0 ? Math.round((data.mfaReport.coveredCount / data.mfaReport.totalUsers) * 100) : 100;
    snapItems.push({
      label: "MFA Coverage",
      value: `${pct}%`,
      status: pct >= 100 ? "good" : "warn",
    });
  }
  if (data.deviceHealth) {
    snapItems.push({
      label: "Patch Compliance",
      value: `${data.deviceHealth.patchCompliancePercent}%`,
      status: data.deviceHealth.patchCompliancePercent >= 90 ? "good" : "warn",
    });
    snapItems.push({
      label: "Devices Needing Replacement",
      value: data.deviceHealth.needsReplacementCount === 0 ? "None" : `${data.deviceHealth.needsReplacementCount}`,
      status: data.deviceHealth.needsReplacementCount === 0 ? "good" : "warn",
    });
  }
  if (data.tickets) {
    snapItems.push({
      label: "Lingering Tickets (30+ days)",
      value: data.tickets.oldOpenTickets.length === 0 ? "None" : `${data.tickets.oldOpenTickets.length}`,
      status: data.tickets.oldOpenTickets.length === 0 ? "good" : "warn",
    });
  }

  if (snapItems.length > 0) {
    const statusColors = { good: "#16a34a", warn: "#dc2626", neutral: "#6b7280" };
    const statusBg = { good: "#f0fdf4", warn: "#fef2f2", neutral: "#f9fafb" };
    sections += `
    <div class="snapshot-grid">
      ${snapItems.map(s => `
        <div class="snap-card" style="border-left:3px solid ${statusColors[s.status]};background:${statusBg[s.status]}">
          <div class="snap-label">${s.label}</div>
          <div class="snap-value" style="color:${statusColors[s.status]}">${s.value}</div>
        </div>`).join("")}
    </div>`;
  }

  // === SECTION 1: OPERATIONAL READINESS ===
  const opItems: string[] = [];

  if (data.security) {
    const sec = data.security;
    opItems.push(goodBad(sec.pendingIncidents === 0,
      `No unresolved security incidents`,
      `${sec.pendingIncidents} security incident(s) need attention`));

    if (sec.totalIncidents > 0) {
      opItems.push(`<div class="sub">${sec.totalIncidents} incident(s) detected in 6 months, ${sec.resolvedIncidents} resolved${trendBadge(sec.totalIncidents, prev?.totalIncidents, false)}</div>`);
    }

    if (sec.managedAntivirusCount > 0 || sec.antivirusNotProtectedCount > 0) {
      opItems.push(goodBad(sec.antivirusNotProtectedCount === 0,
        `All devices have managed antivirus`,
        `${sec.antivirusNotProtectedCount} device(s) lack antivirus protection`));
    }

    if (sec.satLearnerCount !== null) {
      const satGap = sec.satTotalUsers ? sec.satTotalUsers - sec.satLearnerCount : 0;
      opItems.push(goodBad(satGap === 0,
        `All users enrolled in security awareness training`,
        `${satGap} user(s) not enrolled in security training`));
    }

    if (sec.phishingClickRate !== null) {
      opItems.push(goodBad(sec.phishingClickRate <= 5,
        `Phishing click rate: ${sec.phishingClickRate}% (below industry avg)`,
        `Phishing click rate: ${sec.phishingClickRate}% (target: under 5%)`));
    }
  }

  if (data.mfaReport) {
    const mfa = data.mfaReport;
    const coveragePct = mfa.totalUsers > 0 ? Math.round((mfa.coveredCount / mfa.totalUsers) * 100) : 100;
    opItems.push(goodBad(mfa.uncoveredCount === 0,
      `100% MFA coverage (${mfa.totalUsers} users)`,
      `${mfa.uncoveredCount} user(s) without MFA (${coveragePct}% covered)${trendPctBadge(coveragePct, prev?.mfaCoveragePercent, true)}`));
    if (mfa.uncoveredCount > 0 && mfa.uncoveredUsers.length > 0) {
      opItems.push(`<div class="sub callout-red">${mfa.uncoveredUsers.map(u => u.displayName).join(", ")}</div>`);
    }
  }

  if (data.tickets) {
    const tk = data.tickets;
    opItems.push(goodBad(tk.oldOpenTickets.length === 0,
      `No lingering support requests`,
      `${tk.oldOpenTickets.length} request(s) open 30+ days`));
    opItems.push(`<div class="sub">${tk.totalTickets} total requests in 6 months${trendBadge(tk.totalTickets, prev?.totalTickets, false)}</div>`);
  }

  sections += buildSection("Operational Readiness", "Are day-to-day operations running smoothly?", opItems);

  // === SECTION 2: CAPACITY & INFRASTRUCTURE ===
  const capItems: string[] = [];

  if (data.deviceHealth) {
    const dh = data.deviceHealth;
    const tc = dh.deviceTypeCounts;
    const breakdown = tc ? [
      tc.windowsLaptops > 0 ? `${tc.windowsLaptops} Win Laptop` : "",
      tc.windowsDesktops > 0 ? `${tc.windowsDesktops} Win Desktop` : "",
      tc.macLaptops > 0 ? `${tc.macLaptops} Mac` : "",
      tc.windowsServers > 0 ? `${tc.windowsServers} Server` : "",
    ].filter(Boolean).join(", ") : "";

    capItems.push(`<div class="sub"><strong>${dh.totalDevices} devices</strong> managed${breakdown ? ` (${breakdown})` : ""}${trendBadge(dh.totalDevices, prev?.totalDevices, true)}</div>`);

    capItems.push(goodBad(dh.needsReplacementCount === 0,
      `No hardware flagged for replacement`,
      `${dh.needsReplacementCount} device(s) aging out or past end of life`));

    if (dh.oldDevices.length > 0) {
      capItems.push(`<div class="sub callout-red">${dh.oldDevices.map(d => `${d.systemName} (${d.ageSource === "model" ? "~" : ""}${d.age}yr)`).join(", ")}</div>`);
    }

    capItems.push(goodBad(dh.eolOsDevices.length === 0,
      `All devices on supported operating systems`,
      `${dh.eolOsDevices.length} device(s) running unsupported OS`));

    if (dh.eolOsDevices.length > 0) {
      capItems.push(`<div class="sub callout-amber">${dh.eolOsDevices.map(d => `${d.systemName} (${d.osName})`).join(", ")}</div>`);
    }

    capItems.push(goodBad(dh.patchCompliancePercent >= 90,
      `Patch compliance at ${dh.patchCompliancePercent}%`,
      `Patch compliance at ${dh.patchCompliancePercent}% \u2014 ${dh.pendingPatchCount} patches pending 30+ days`));

    if (dh.staleDevices && dh.staleDevices.length > 0) {
      capItems.push(goodBad(false, "", `${dh.staleDevices.length} device(s) inactive 30+ days`));
    }
  }

  sections += buildSection("Infrastructure & Capacity", "Is the hardware ready for what's ahead?", capItems);

  // === SECTION 3: FINANCIAL EFFICIENCY ===
  const finItems: string[] = [];

  if (data.licenseReport) {
    const lic = data.licenseReport;
    if (lic.totalWasted === 0) {
      finItems.push(goodBad(true, `All Microsoft 365 licenses fully utilized \u2014 no waste detected`, ""));
    } else {
      const monthlySavings = lic.totalMonthlyWaste;
      const annualSavings = lic.totalAnnualWaste;

      if (monthlySavings > 0) {
        finItems.push(`
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:12px 16px;margin-bottom:8px">
          <div style="font-weight:600;font-size:14px;color:#15803d;margin-bottom:4px">Microsoft 365 License Cleanup Opportunity</div>
          <div style="font-size:13px;color:#166534;line-height:1.6">
            We identified <strong>${lic.totalWasted} unused license${lic.totalWasted !== 1 ? "s" : ""}</strong> that can be removed or reallocated.
            By cleaning these up, you would save approximately <strong>$${monthlySavings.toFixed(0)}/month</strong> ($${annualSavings.toFixed(0)}/year).
          </div>
        </div>`);
      } else {
        finItems.push(goodBad(false, "", `${lic.totalWasted} unused license(s) detected \u2014 review recommended`));
      }

      const wastefulLicenses = lic.licenses.filter(l => l.wasted > 0);
      if (wastefulLicenses.length > 0) {
        finItems.push(`
        <table>
          <tr><th>License</th><th>In Use</th><th>Total</th><th>Unused</th><th>Savings/mo</th></tr>
          ${wastefulLicenses.map(l => `<tr><td>${l.licenseName}</td><td>${l.quantityUsed}</td><td>${l.totalLicenses}</td><td class="attention-text">${l.wasted}</td><td class="attention-text">${l.monthlyWastedCost > 0 ? "$" + l.monthlyWastedCost.toFixed(0) : "\u2014"}</td></tr>`).join("")}
        </table>`);
      }
    }
  }

  sections += buildSection("Financial Efficiency", "Are technology investments being used wisely?", finItems);

  // === SECTION 4: RECOMMENDED ACTIONS ===
  if (data.roadmap && data.roadmap.items.length > 0) {
    const priorityLabels: Record<string, string> = { urgent: "Act Now", plan_for: "Plan For", nice_to_have: "Consider" };
    const priorityColors: Record<string, string> = { urgent: "#dc2626", plan_for: "#2563eb", nice_to_have: "#6b7280" };
    const priorityBg: Record<string, string> = { urgent: "#fef2f2", plan_for: "#eff6ff", nice_to_have: "#f9fafb" };

    const actionItems: string[] = [];

    if (data.roadmap.executiveSummary) {
      actionItems.push(`
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:12px 16px;margin-bottom:8px">
          <div style="font-weight:600;font-size:13px;margin-bottom:4px;color:#334155">Executive Summary</div>
          <div style="font-size:12px;color:#475569;line-height:1.6">${data.roadmap.executiveSummary}</div>
        </div>`);
    }

    actionItems.push(...data.roadmap.items.map(item => `
        <div class="action-card" style="border-left:3px solid ${priorityColors[item.priority]};background:${priorityBg[item.priority]}">
          <div class="action-header">
            <strong>${item.title}</strong>
            <span class="priority-tag" style="color:${priorityColors[item.priority]}">${priorityLabels[item.priority]}</span>
          </div>
          <div class="action-why">${item.businessImpact}</div>
        </div>`));
    sections += buildSection("Recommended Next Steps", "Prioritized actions to keep your environment healthy", actionItems);
  }

  // === TREND COMPARISON ===
  if (prev) {
    const prevDate = new Date(prev.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    const trendRows: string[] = [];

    const addRow = (label: string, current: number | null | undefined, previous: number | null | undefined, higherIsBetter: boolean, format?: (v: number) => string) => {
      if (current === null || current === undefined || previous === null || previous === undefined) return;
      const diff = current - previous;
      const fmt = format || ((v: number) => v.toString());
      const improved = higherIsBetter ? diff > 0 : diff < 0;
      const noChange = diff === 0;
      const color = noChange ? "#6b7280" : improved ? "#16a34a" : "#dc2626";
      const icon = noChange ? "=" : improved ? "&#9650;" : "&#9660;";
      trendRows.push(`<tr><td>${label}</td><td style="text-align:center">${fmt(previous)}</td><td style="text-align:center">${fmt(current)}</td><td style="text-align:center;color:${color};font-weight:600">${icon}</td></tr>`);
    };

    addRow("Devices Managed", data.deviceHealth?.totalDevices, prev.totalDevices, true);
    addRow("Needs Replacement", data.deviceHealth?.needsReplacementCount, prev.needsReplacementCount, false);
    addRow("Patch Compliance", data.deviceHealth?.patchCompliancePercent, prev.patchCompliancePercent, true, v => `${Math.round(v)}%`);
    addRow("Security Incidents", data.security?.totalIncidents, prev.totalIncidents, false);
    addRow("Protected Devices", data.security?.activeAgents, prev.activeAgents, true);
    addRow("Support Requests", data.tickets?.totalTickets, prev.totalTickets, false);
    if (data.mfaReport) {
      const currentPct = data.mfaReport.totalUsers > 0 ? Math.round((data.mfaReport.coveredCount / data.mfaReport.totalUsers) * 100) : null;
      addRow("MFA Coverage", currentPct, prev.mfaCoveragePercent, true, v => `${Math.round(v)}%`);
    }

    if (trendRows.length > 0) {
      const trendTable = `<table class="trend-table">
          <tr><th>Metric</th><th style="text-align:center">Then</th><th style="text-align:center">Now</th><th style="text-align:center">Trend</th></tr>
          ${trendRows.join("")}
        </table>`;
      sections += buildSection("Progress Since Last Review", `Comparing to ${prevDate}`, [trendTable]);
    }
  }

  // === APPENDIX: COMPUTERS & USERS ===
  const hasDevices = data.deviceUserInventory && data.deviceUserInventory.length > 0;
  const mfaUserList = data.mfaReport?.allUsers || data.mfaReport?.uncoveredUsers;
  const hasUsers = mfaUserList && mfaUserList.length > 0;

  if (hasDevices || hasUsers) {
    const appendixItems: string[] = [];

    if (hasDevices) {
      const sorted = [...data.deviceUserInventory!].sort((a, b) => {
        const ageA = a.age ?? -1;
        const ageB = b.age ?? -1;
        if (ageB !== ageA) return ageB - ageA;
        return a.hostname.localeCompare(b.hostname);
      });
      const deviceRows = sorted.map(d => {
        const ageStr = d.age !== undefined && d.age !== null ? `${d.ageSource === "model" ? "~" : ""}${d.age}y` : "\u2014";
        const ageColor = d.age !== undefined && d.age !== null && d.age >= 5 ? "color:#dc2626;font-weight:600" : "";
        return `<tr>
          <td style="font-family:monospace;font-size:11px">${d.hostname}</td>
          <td>${d.lastLoggedInUser || '<span style="color:#9ca3af">\u2014</span>'}</td>
          <td>${d.deviceType}</td>
          <td style="font-size:11px">${d.osName || "\u2014"}</td>
          <td style="text-align:center;${ageColor}">${ageStr}</td>
        </tr>`;
      });

      appendixItems.push(
        `<div style="margin-bottom:4px"><strong>${sorted.length} Managed Computers</strong></div>
        <table>
          <tr><th>Hostname</th><th>User</th><th>Type</th><th>OS</th><th style="text-align:center">Age</th></tr>
          ${deviceRows.join("")}
        </table>`
      );
    }

    if (hasUsers) {
      const allUsers = data.mfaReport!.allUsers || data.mfaReport!.uncoveredUsers || [];
      const sortedUsers = [...allUsers].sort((a, b) => a.displayName.localeCompare(b.displayName));
      const userRows = sortedUsers.map(u => {
        const mfaIcon = u.isCovered
          ? '<span style="color:#16a34a">&#10003;</span>'
          : '<span style="color:#dc2626">&#10007;</span>';
        const method = u.coverageMethod === "conditionalAccess" ? "Conditional Access"
          : u.coverageMethod === "securityDefaults" ? "Security Defaults"
          : u.coverageMethod === "perUser" ? "Per-User"
          : '<span style="color:#9ca3af">\u2014</span>';
        return `<tr>
          <td>${u.displayName}</td>
          <td style="font-size:11px">${u.email}</td>
          <td style="text-align:center">${mfaIcon}</td>
          <td style="font-size:11px">${method}</td>
        </tr>`;
      });

      appendixItems.push(
        `<div style="margin-top:16px;margin-bottom:4px"><strong>${allUsers.length} Licensed &amp; Enabled Microsoft 365 Users</strong></div>
        <table>
          <tr><th>Name</th><th>Email</th><th style="text-align:center">MFA</th><th>MFA Method</th></tr>
          ${userRows.join("")}
        </table>`
      );
    }

    sections += buildSection(
      "Appendix",
      "Computers & Users",
      appendixItems
    );
  }

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <title>Technology Business Review \u2014 ${data.clientName}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Poppins', -apple-system, BlinkMacSystemFont, sans-serif; color: #394442; max-width: 780px; margin: 0 auto; padding: 24px 20px; line-height: 1.45; font-size: 12px; }

    .header { text-align: center; margin-bottom: 14px; padding-bottom: 12px; border-bottom: 2px solid #E77125; }
    .header .logo { display: inline-flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .header .logo-mark { width: 28px; height: 28px; object-fit: contain; }
    .header .logo-text { font-size: 13px; font-weight: 600; color: #394442; }
    .header h1 { font-size: 18px; color: #E77125; margin-bottom: 2px; letter-spacing: -0.3px; }
    .header .client { font-size: 16px; font-weight: 600; }
    .header .date { color: #6b7280; font-size: 11px; margin-top: 2px; }
    .header .tagline { color: #6b7280; font-size: 10px; margin-top: 4px; font-style: italic; }

    .snapshot-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 6px; margin-bottom: 12px; }
    .snap-card { padding: 8px 10px; border-radius: 6px; }
    .snap-label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; margin-bottom: 1px; }
    .snap-value { font-size: 15px; font-weight: 700; }

    .section { margin-bottom: 10px; }
    .section-top { }
    .section-header { margin-bottom: 6px; padding-bottom: 4px; border-bottom: 1px solid #e5e7eb; padding-top: 2px; }
    .section-header h2 { font-size: 13px; color: #E77125; margin-bottom: 1px; }
    .section-header .subtitle { font-size: 10px; color: #6b7280; }

    .item { padding: 3px 0; font-size: 12px; display: flex; align-items: flex-start; gap: 6px; }
    .item .icon { flex-shrink: 0; font-size: 12px; line-height: 1.45; }
    .item.good .icon { color: #16a34a; }
    .item.attention .icon { color: #dc2626; }

    .sub { font-size: 11px; margin: 2px 0 2px 20px; color: #6b7280; }
    .callout-red { color: #dc2626; }
    .callout-amber { color: #d97706; }

    table { width: 100%; border-collapse: collapse; font-size: 11px; margin-top: 4px; }
    th, td { padding: 3px 8px; text-align: left; border-bottom: 1px solid #e5e7eb; }
    th { background: #f9fafb; font-weight: 600; font-size: 10px; text-transform: uppercase; letter-spacing: 0.3px; }
    .attention-text { color: #dc2626; font-weight: 600; }

    .action-card { padding: 8px 12px; border-radius: 6px; margin-bottom: 4px; }
    .action-header { display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 2px; }
    .action-header strong { font-size: 12px; }
    .priority-tag { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
    .action-why { font-size: 11px; color: #6b7280; }

    .trend-table th, .trend-table td { padding: 3px 8px; }

    .footer { text-align: center; margin-top: 16px; padding-top: 10px; border-top: 2px solid #E77125; color: #6b7280; font-size: 10px; }
    .footer .footer-logo { display: inline-flex; align-items: center; gap: 6px; margin-bottom: 6px; }
    .footer .footer-logo img { width: 20px; height: 20px; object-fit: contain; }
    .footer .footer-logo span { font-size: 11px; font-weight: 600; color: #394442; }
    @media print { body { padding: 12px; } .section-header { break-after: avoid; page-break-after: avoid; } }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">
      <img class="logo-mark" src="data:image/png;base64,${getLogoBase64()}" alt="Pelycon" />
      <span class="logo-text">Pelycon Technologies</span>
    </div>
    <h1>Technology Business Review</h1>
    <div class="client">${data.clientName}</div>
    <div class="date">${today}</div>
    <div class="tagline">Your technology. No surprises.</div>
  </div>
  ${sections}
  <div class="footer">
    <div class="footer-logo">
      <img src="data:image/png;base64,${getLogoBase64()}" alt="Pelycon" />
      <span>Pelycon Technologies</span>
    </div>
    <p>Next review: <strong>${nextTbrStr}</strong></p>
    <p style="margin-top:4px">Confidential &middot; Prepared for ${data.clientName}</p>
  </div>
</body>
</html>`;
}
